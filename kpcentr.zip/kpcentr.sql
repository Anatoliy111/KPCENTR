-- MariaDB dump 10.19  Distrib 10.5.11-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: kpcentr
-- ------------------------------------------------------
-- Server version	10.5.11-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_access_log`
--

DROP TABLE IF EXISTS `backend_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_access_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_access_log`
--

LOCK TABLES `backend_access_log` WRITE;
/*!40000 ALTER TABLE `backend_access_log` DISABLE KEYS */;
INSERT INTO `backend_access_log` VALUES (1,1,'127.0.0.1','2022-05-18 11:11:59','2022-05-18 11:11:59'),(2,1,'127.0.0.1','2022-05-18 11:19:59','2022-05-18 11:19:59'),(3,1,'127.0.0.1','2022-05-30 12:34:11','2022-05-30 12:34:11'),(4,1,'127.0.0.1','2022-05-30 12:50:16','2022-05-30 12:50:16'),(5,1,'127.0.0.1','2022-06-16 07:45:23','2022-06-16 07:45:23');
/*!40000 ALTER TABLE `backend_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_groups`
--

DROP TABLE IF EXISTS `backend_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_new_user_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`),
  KEY `code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_groups`
--

LOCK TABLES `backend_user_groups` WRITE;
/*!40000 ALTER TABLE `backend_user_groups` DISABLE KEYS */;
INSERT INTO `backend_user_groups` VALUES (1,'Owners','2022-05-17 07:12:18','2022-05-17 07:12:18','owners','Default group for website owners.',0);
/*!40000 ALTER TABLE `backend_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_preferences`
--

DROP TABLE IF EXISTS `backend_user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_item_index` (`user_id`,`namespace`,`group`,`item`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_preferences`
--

LOCK TABLES `backend_user_preferences` WRITE;
/*!40000 ALTER TABLE `backend_user_preferences` DISABLE KEYS */;
INSERT INTO `backend_user_preferences` VALUES (1,1,'backend','backend','preferences','{\"locale\":\"uk\",\"fallback_locale\":\"en\",\"timezone\":\"Europe\\/Kiev\",\"editor_font_size\":\"12\",\"editor_word_wrap\":\"fluid\",\"editor_code_folding\":\"manual\",\"editor_tab_size\":\"4\",\"editor_theme\":\"twilight\",\"editor_show_invisibles\":\"0\",\"editor_highlight_active_line\":\"1\",\"editor_use_hard_tabs\":\"0\",\"editor_show_gutter\":\"1\",\"editor_auto_closing\":\"0\",\"editor_autocompletion\":\"manual\",\"editor_enable_snippets\":\"0\",\"editor_display_indent_guides\":\"0\",\"editor_show_print_margin\":\"0\",\"user_id\":1}'),(2,1,'backend','reportwidgets','dashboard','{\"welcome\":{\"class\":\"Backend\\\\ReportWidgets\\\\Welcome\",\"sortOrder\":\"50\",\"configuration\":{\"title\":\"\\u041b\\u0430\\u0441\\u043a\\u0430\\u0432\\u043e \\u043f\\u0440\\u043e\\u0441\\u0438\\u043c\\u043e\",\"ocWidgetWidth\":7,\"ocWidgetNewRow\":null}},\"systemStatus\":{\"class\":\"System\\\\ReportWidgets\\\\Status\",\"sortOrder\":\"70\",\"configuration\":{\"ocWidgetWidth\":7}},\"activeTheme\":{\"class\":\"Cms\\\\ReportWidgets\\\\ActiveTheme\",\"sortOrder\":\"60\",\"configuration\":{\"title\":\"\\u0412\\u0435\\u0431-\\u0441\\u0430\\u0439\\u0442\",\"ocWidgetWidth\":\"5\",\"ocWidgetNewRow\":null}}}');
/*!40000 ALTER TABLE `backend_user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_roles`
--

DROP TABLE IF EXISTS `backend_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_unique` (`name`),
  KEY `role_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_roles`
--

LOCK TABLES `backend_user_roles` WRITE;
/*!40000 ALTER TABLE `backend_user_roles` DISABLE KEYS */;
INSERT INTO `backend_user_roles` VALUES (1,'Publisher','publisher','Site editor with access to publishing tools.','',1,'2022-05-17 07:12:18','2022-05-17 07:12:18'),(2,'Developer','developer','Site administrator with access to developer tools.','',1,'2022-05-17 07:12:18','2022-05-17 07:12:18');
/*!40000 ALTER TABLE `backend_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_throttle`
--

DROP TABLE IF EXISTS `backend_user_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backend_user_throttle_user_id_index` (`user_id`),
  KEY `backend_user_throttle_ip_address_index` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_throttle`
--

LOCK TABLES `backend_user_throttle` WRITE;
/*!40000 ALTER TABLE `backend_user_throttle` DISABLE KEYS */;
INSERT INTO `backend_user_throttle` VALUES (1,1,'127.0.0.1',0,NULL,0,NULL,0,NULL);
/*!40000 ALTER TABLE `backend_user_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_users`
--

DROP TABLE IF EXISTS `backend_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_unique` (`login`),
  UNIQUE KEY `email_unique` (`email`),
  KEY `act_code_index` (`activation_code`),
  KEY `reset_code_index` (`reset_password_code`),
  KEY `admin_role_index` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_users`
--

LOCK TABLES `backend_users` WRITE;
/*!40000 ALTER TABLE `backend_users` DISABLE KEYS */;
INSERT INTO `backend_users` VALUES (1,'Admin','Person','admin','admin@domain.tld','$2y$10$CmLYeOus249Qpbj1YD6IjeKLLlK04vj9ZrC/lmBlO6pjeZt0hc4se',NULL,'$2y$10$aeuB2IPhvbVcgYtav.pqMewt8AbQvQ8B0xzxM8GPmrPryosKxGXqG',NULL,'',1,2,NULL,'2022-06-16 07:45:23','2022-05-17 07:12:18','2022-06-16 07:45:23',NULL,1);
/*!40000 ALTER TABLE `backend_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_users_groups`
--

DROP TABLE IF EXISTS `backend_users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`user_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_users_groups`
--

LOCK TABLES `backend_users_groups` WRITE;
/*!40000 ALTER TABLE `backend_users_groups` DISABLE KEYS */;
INSERT INTO `backend_users_groups` VALUES (1,1);
/*!40000 ALTER TABLE `backend_users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_data`
--

DROP TABLE IF EXISTS `cms_theme_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_data_theme_index` (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_data`
--

LOCK TABLES `cms_theme_data` WRITE;
/*!40000 ALTER TABLE `cms_theme_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_logs`
--

DROP TABLE IF EXISTS `cms_theme_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_logs_type_index` (`type`),
  KEY `cms_theme_logs_theme_index` (`theme`),
  KEY `cms_theme_logs_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_logs`
--

LOCK TABLES `cms_theme_logs` WRITE;
/*!40000 ALTER TABLE `cms_theme_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_templates`
--

DROP TABLE IF EXISTS `cms_theme_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(10) unsigned NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_templates_source_index` (`source`),
  KEY `cms_theme_templates_path_index` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_templates`
--

LOCK TABLES `cms_theme_templates` WRITE;
/*!40000 ALTER TABLE `cms_theme_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deferred_bindings`
--

DROP TABLE IF EXISTS `deferred_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deferred_bindings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `master_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `master_field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_bind` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deferred_bindings_master_type_index` (`master_type`),
  KEY `deferred_bindings_master_field_index` (`master_field`),
  KEY `deferred_bindings_slave_type_index` (`slave_type`),
  KEY `deferred_bindings_slave_id_index` (`slave_id`),
  KEY `deferred_bindings_session_key_index` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deferred_bindings`
--

LOCK TABLES `deferred_bindings` WRITE;
/*!40000 ALTER TABLE `deferred_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `deferred_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2013_10_01_000001_Db_Deferred_Bindings',1),(2,'2013_10_01_000002_Db_System_Files',1),(3,'2013_10_01_000003_Db_System_Plugin_Versions',1),(4,'2013_10_01_000004_Db_System_Plugin_History',1),(5,'2013_10_01_000005_Db_System_Settings',1),(6,'2013_10_01_000006_Db_System_Parameters',1),(7,'2013_10_01_000007_Db_System_Add_Disabled_Flag',1),(8,'2013_10_01_000008_Db_System_Mail_Templates',1),(9,'2013_10_01_000009_Db_System_Mail_Layouts',1),(10,'2014_10_01_000010_Db_Jobs',1),(11,'2014_10_01_000011_Db_System_Event_Logs',1),(12,'2014_10_01_000012_Db_System_Request_Logs',1),(13,'2014_10_01_000013_Db_System_Sessions',1),(14,'2015_10_01_000014_Db_System_Mail_Layout_Rename',1),(15,'2015_10_01_000015_Db_System_Add_Frozen_Flag',1),(16,'2015_10_01_000016_Db_Cache',1),(17,'2015_10_01_000017_Db_System_Revisions',1),(18,'2015_10_01_000018_Db_FailedJobs',1),(19,'2016_10_01_000019_Db_System_Plugin_History_Detail_Text',1),(20,'2016_10_01_000020_Db_System_Timestamp_Fix',1),(21,'2017_08_04_121309_Db_Deferred_Bindings_Add_Index_Session',1),(22,'2017_10_01_000021_Db_System_Sessions_Update',1),(23,'2017_10_01_000022_Db_Jobs_FailedJobs_Update',1),(24,'2017_10_01_000023_Db_System_Mail_Partials',1),(25,'2017_10_23_000024_Db_System_Mail_Layouts_Add_Options_Field',1),(26,'2013_10_01_000001_Db_Backend_Users',2),(27,'2013_10_01_000002_Db_Backend_User_Groups',2),(28,'2013_10_01_000003_Db_Backend_Users_Groups',2),(29,'2013_10_01_000004_Db_Backend_User_Throttle',2),(30,'2014_01_04_000005_Db_Backend_User_Preferences',2),(31,'2014_10_01_000006_Db_Backend_Access_Log',2),(32,'2014_10_01_000007_Db_Backend_Add_Description_Field',2),(33,'2015_10_01_000008_Db_Backend_Add_Superuser_Flag',2),(34,'2016_10_01_000009_Db_Backend_Timestamp_Fix',2),(35,'2017_10_01_000010_Db_Backend_User_Roles',2),(36,'2018_12_16_000011_Db_Backend_Add_Deleted_At',2),(37,'2014_10_01_000001_Db_Cms_Theme_Data',3),(38,'2016_10_01_000002_Db_Cms_Timestamp_Fix',3),(39,'2017_10_01_000003_Db_Cms_Theme_Logs',3),(40,'2018_11_01_000001_Db_Cms_Theme_Templates',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_blog_categories`
--

DROP TABLE IF EXISTS `rainlab_blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_blog_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `nest_left` int(11) DEFAULT NULL,
  `nest_right` int(11) DEFAULT NULL,
  `nest_depth` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rainlab_blog_categories_slug_index` (`slug`),
  KEY `rainlab_blog_categories_parent_id_index` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_blog_categories`
--

LOCK TABLES `rainlab_blog_categories` WRITE;
/*!40000 ALTER TABLE `rainlab_blog_categories` DISABLE KEYS */;
INSERT INTO `rainlab_blog_categories` VALUES (1,'Uncategorized','uncategorized',NULL,NULL,NULL,1,2,0,'2022-06-16 08:04:26','2022-06-16 08:04:26'),(2,'Новини','novini',NULL,'Новини1',NULL,3,4,0,'2022-06-16 08:28:37','2022-06-16 08:28:37');
/*!40000 ALTER TABLE `rainlab_blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_blog_posts`
--

DROP TABLE IF EXISTS `rainlab_blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_blog_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `metadata` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rainlab_blog_posts_user_id_index` (`user_id`),
  KEY `rainlab_blog_posts_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_blog_posts`
--

LOCK TABLES `rainlab_blog_posts` WRITE;
/*!40000 ALTER TABLE `rainlab_blog_posts` DISABLE KEYS */;
INSERT INTO `rainlab_blog_posts` VALUES (1,1,'First blog post','first-blog-post','The first ever blog post is here. It might be a good idea to update this post with some more relevant content.','This is your first ever **blog post**! It might be a good idea to update this post with some more relevant content.\n\nYou can edit this content by selecting **Blog** from the administration back-end menu.\n\n*Enjoy the good times!*','<p>This is your first ever <strong>blog post</strong>! It might be a good idea to update this post with some more relevant content.</p>\n<p>You can edit this content by selecting <strong>Blog</strong> from the administration back-end menu.</p>\n<p><em>Enjoy the good times!</em></p>','2022-06-16 08:04:26',1,'2022-06-16 08:04:26','2022-06-16 08:04:26',NULL),(2,1,'Шановні мешканці міста!','shanovni-meshkanci-mista','В напружених умовах війни в країні, найголовнішим пріоритетом для фахівців Дніпроводоканалу являється безперебійне забезпечення мешканців міста послугами з централізованого водопостачання та водовідведення.','В напружених умовах війни в країні, найголовнішим пріоритетом для фахівців Дніпроводоканалу являється безперебійне забезпечення мешканців міста послугами з централізованого водопостачання та водовідведення.\r\n\r\nЩодня виконуються ремонтні роботи з усунення поривів, витоків та засмічень на водопровідно-каналізаційних мережах. В той же час фахівці надають дистанційні консультації споживачам.\r\n\r\nПодальша стабільна робота нашого підприємства суттєво залежить від наявності матеріалів, необхідних для створення та надання мешканцям міста якісних та безперебійних послуг.\r\n\r\nНажаль виконання всіх необхідних для роботи підприємства заходів, можливо лише за участі наших споживачів.\r\n\r\nУ зв’язку з чим, шановні мешканці міста, звертаємось на вашу адресу з проханням знайти фінансову та технічну можливість здійснити оплату за спожиті послуги централізованого водопостачання та водовідведення.','<p>В напружених умовах війни в країні, найголовнішим пріоритетом для фахівців Дніпроводоканалу являється безперебійне забезпечення мешканців міста послугами з централізованого водопостачання та водовідведення.</p>\n<p>Щодня виконуються ремонтні роботи з усунення поривів, витоків та засмічень на водопровідно-каналізаційних мережах. В той же час фахівці надають дистанційні консультації споживачам.</p>\n<p>Подальша стабільна робота нашого підприємства суттєво залежить від наявності матеріалів, необхідних для створення та надання мешканцям міста якісних та безперебійних послуг.</p>\n<p>Нажаль виконання всіх необхідних для роботи підприємства заходів, можливо лише за участі наших споживачів.</p>\n<p>У зв’язку з чим, шановні мешканці міста, звертаємось на вашу адресу з проханням знайти фінансову та технічну можливість здійснити оплату за спожиті послуги централізованого водопостачання та водовідведення.</p>','2022-06-15 18:00:00',1,'2022-06-16 08:34:58','2022-06-16 08:34:58',NULL),(3,1,'До уваги мешканців приватного сектору!','do-uvagi-meshkanciv-privatnogo-sektoru','З початком поливного сезону для мешканців приватного сектору, у власників приватних житлових будинків виникають питання, пов’язані з повіркою та подальшою експлуатацією приладів обліку питної води.','З початком поливного сезону для мешканців приватного сектору, у власників приватних житлових будинків виникають питання, пов’язані з повіркою та подальшою експлуатацією приладів обліку питної води.\r\n\r\nШановні мешканці приватного сектору повідомляємо наступне.\r\n\r\nУ зв’язку з внесенням змін до Законів України «Про комерційний облік теплової енергії та водопостачання» та «Про житлово-комунальні послуги», з 1 січня 2022 року до усіх споживачів, в тому числі населення приватного сектору, розташованого у окремих будівлях, з якими укладені індивідуальні договори про надання послуг з централізованого водопостачання та/або централізованого водовідведення (у паперовому варіанті або у варіанті публічних договорів приєднання), застосовується плата за абонентське обслуговування.\r\n\r\nЗазначений платіж є обов’язковим і враховує таку складову, як обслуговування кожного водолічильника, взятого на абонентський облік, місця його розташування та діаметру. Ця складова є змінною і залежить насамперед від типів наявних вузлів комерційного обліку води, їх кількості та місця розміщення (у приміщенні або у колодязі).\r\n\r\nТобто, споживачі, які мешкають у приватному секторі, у межах граничного розміру плати за абонентське обслуговування сплачують і місячну вартість обслуговування за кожен вузол комерційного обліку води, взятий на абонентський облік.\r\n\r\nНа підставі зазначеного вище, для мешканців приватного сектору, яким нараховується плата за абонентське обслуговування, роботи з повірки приладів обліку питної води здійснюють фахівці КП «Дніпровдоканал» без додаткової окремо сплаченої вартості послуг з повірки водолічильників.','<p>З початком поливного сезону для мешканців приватного сектору, у власників приватних житлових будинків виникають питання, пов’язані з повіркою та подальшою експлуатацією приладів обліку питної води.</p>\n<p>Шановні мешканці приватного сектору повідомляємо наступне.</p>\n<p>У зв’язку з внесенням змін до Законів України «Про комерційний облік теплової енергії та водопостачання» та «Про житлово-комунальні послуги», з 1 січня 2022 року до усіх споживачів, в тому числі населення приватного сектору, розташованого у окремих будівлях, з якими укладені індивідуальні договори про надання послуг з централізованого водопостачання та/або централізованого водовідведення (у паперовому варіанті або у варіанті публічних договорів приєднання), застосовується плата за абонентське обслуговування.</p>\n<p>Зазначений платіж є обов’язковим і враховує таку складову, як обслуговування кожного водолічильника, взятого на абонентський облік, місця його розташування та діаметру. Ця складова є змінною і залежить насамперед від типів наявних вузлів комерційного обліку води, їх кількості та місця розміщення (у приміщенні або у колодязі).</p>\n<p>Тобто, споживачі, які мешкають у приватному секторі, у межах граничного розміру плати за абонентське обслуговування сплачують і місячну вартість обслуговування за кожен вузол комерційного обліку води, взятий на абонентський облік.</p>\n<p>На підставі зазначеного вище, для мешканців приватного сектору, яким нараховується плата за абонентське обслуговування, роботи з повірки приладів обліку питної води здійснюють фахівці КП «Дніпровдоканал» без додаткової окремо сплаченої вартості послуг з повірки водолічильників.</p>','2022-06-15 18:00:00',1,'2022-06-16 08:36:37','2022-06-16 08:36:37',NULL),(4,1,'ячсичсяичсяи','yachsichsyaichsyai','ячсичясичсяи','ячсичясичясичсяи','<p>ячсичясичясичсяи</p>','2022-06-15 18:00:00',1,'2022-06-16 08:37:23','2022-06-16 08:37:23',NULL);
/*!40000 ALTER TABLE `rainlab_blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_blog_posts_categories`
--

DROP TABLE IF EXISTS `rainlab_blog_posts_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_blog_posts_categories` (
  `post_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`post_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_blog_posts_categories`
--

LOCK TABLES `rainlab_blog_posts_categories` WRITE;
/*!40000 ALTER TABLE `rainlab_blog_posts_categories` DISABLE KEYS */;
INSERT INTO `rainlab_blog_posts_categories` VALUES (2,2),(3,2),(4,2);
/*!40000 ALTER TABLE `rainlab_blog_posts_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_forum_channels`
--

DROP TABLE IF EXISTS `rainlab_forum_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_forum_channels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nest_left` int(11) DEFAULT NULL,
  `nest_right` int(11) DEFAULT NULL,
  `nest_depth` int(11) DEFAULT NULL,
  `count_topics` int(11) NOT NULL DEFAULT 0,
  `count_posts` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_hidden` tinyint(1) NOT NULL DEFAULT 0,
  `is_moderated` tinyint(1) NOT NULL DEFAULT 0,
  `embed_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_guarded` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rainlab_forum_channels_slug_unique` (`slug`),
  KEY `rainlab_forum_channels_parent_id_index` (`parent_id`),
  KEY `rainlab_forum_channels_embed_code_index` (`embed_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_forum_channels`
--

LOCK TABLES `rainlab_forum_channels` WRITE;
/*!40000 ALTER TABLE `rainlab_forum_channels` DISABLE KEYS */;
INSERT INTO `rainlab_forum_channels` VALUES (1,NULL,'Channel Orange','channel-orange','A root level forum channel',1,12,0,1,0,'2022-07-06 08:22:54','2022-07-06 08:35:40',0,0,NULL,0),(2,1,'Autumn Leaves','autumn-leaves','Discussion about the season of falling leaves.',2,9,1,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0),(3,2,'September','september','The start of the fall season.',3,4,2,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0),(4,2,'October','october','The middle of the fall season.',5,6,2,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0),(5,2,'November','november','The end of the fall season.',7,8,2,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0),(6,1,'Summer Breeze','summer-breeze','Discussion about the wind at the ocean.',10,11,1,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0),(7,NULL,'Channel Green','channel-green','A root level forum channel',13,18,0,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0),(8,7,'Winter Snow','winter-snow','Discussion about the frosty snow flakes.',14,15,1,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0),(9,7,'Spring Trees','spring-trees','Discussion about the blooming gardens.',16,17,1,0,0,'2022-07-06 08:22:54','2022-07-06 08:22:54',0,0,NULL,0);
/*!40000 ALTER TABLE `rainlab_forum_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_forum_members`
--

DROP TABLE IF EXISTS `rainlab_forum_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_forum_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_posts` int(11) NOT NULL DEFAULT 0,
  `count_topics` int(11) NOT NULL DEFAULT 0,
  `last_active_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_moderator` tinyint(1) NOT NULL DEFAULT 0,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rainlab_forum_members_user_id_index` (`user_id`),
  KEY `rainlab_forum_members_count_posts_index` (`count_posts`),
  KEY `rainlab_forum_members_count_topics_index` (`count_topics`),
  KEY `rainlab_forum_members_last_active_at_index` (`last_active_at`),
  KEY `rainlab_forum_members_is_moderator_index` (`is_moderator`),
  KEY `rainlab_forum_members_is_approved_index` (`is_approved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_forum_members`
--

LOCK TABLES `rainlab_forum_members` WRITE;
/*!40000 ALTER TABLE `rainlab_forum_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainlab_forum_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_forum_posts`
--

DROP TABLE IF EXISTS `rainlab_forum_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_forum_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic_id` int(10) unsigned DEFAULT NULL,
  `member_id` int(10) unsigned DEFAULT NULL,
  `edit_user_id` int(11) DEFAULT NULL,
  `delete_user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `count_links` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rainlab_forum_posts_topic_id_index` (`topic_id`),
  KEY `rainlab_forum_posts_member_id_index` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_forum_posts`
--

LOCK TABLES `rainlab_forum_posts` WRITE;
/*!40000 ALTER TABLE `rainlab_forum_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainlab_forum_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_forum_topic_followers`
--

DROP TABLE IF EXISTS `rainlab_forum_topic_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_forum_topic_followers` (
  `topic_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`topic_id`,`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_forum_topic_followers`
--

LOCK TABLES `rainlab_forum_topic_followers` WRITE;
/*!40000 ALTER TABLE `rainlab_forum_topic_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainlab_forum_topic_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_forum_topics`
--

DROP TABLE IF EXISTS `rainlab_forum_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_forum_topics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_id` int(10) unsigned NOT NULL,
  `start_member_id` int(11) DEFAULT NULL,
  `last_post_id` int(11) DEFAULT NULL,
  `last_post_member_id` int(11) DEFAULT NULL,
  `last_post_at` datetime DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `is_sticky` tinyint(1) NOT NULL DEFAULT 0,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `count_posts` int(11) NOT NULL DEFAULT 0,
  `count_views` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `embed_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rainlab_forum_topics_slug_unique` (`slug`),
  KEY `sticky_post_time` (`is_sticky`,`last_post_at`),
  KEY `rainlab_forum_topics_channel_id_index` (`channel_id`),
  KEY `rainlab_forum_topics_start_member_id_index` (`start_member_id`),
  KEY `rainlab_forum_topics_last_post_at_index` (`last_post_at`),
  KEY `rainlab_forum_topics_is_private_index` (`is_private`),
  KEY `rainlab_forum_topics_is_locked_index` (`is_locked`),
  KEY `rainlab_forum_topics_count_posts_index` (`count_posts`),
  KEY `rainlab_forum_topics_count_views_index` (`count_views`),
  KEY `rainlab_forum_topics_embed_code_index` (`embed_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_forum_topics`
--

LOCK TABLES `rainlab_forum_topics` WRITE;
/*!40000 ALTER TABLE `rainlab_forum_topics` DISABLE KEYS */;
INSERT INTO `rainlab_forum_topics` VALUES (1,'Шановні мешканці міста!','shanovni-meshkantsi-mista',1,0,NULL,NULL,NULL,0,0,0,0,1,'2022-07-06 08:35:40','2022-07-06 08:35:40','shanovni-meshkanci-mista');
/*!40000 ALTER TABLE `rainlab_forum_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_user_mail_blockers`
--

DROP TABLE IF EXISTS `rainlab_user_mail_blockers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_user_mail_blockers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rainlab_user_mail_blockers_email_index` (`email`),
  KEY `rainlab_user_mail_blockers_template_index` (`template`),
  KEY `rainlab_user_mail_blockers_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_user_mail_blockers`
--

LOCK TABLES `rainlab_user_mail_blockers` WRITE;
/*!40000 ALTER TABLE `rainlab_user_mail_blockers` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainlab_user_mail_blockers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_activity` int(11) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_event_logs`
--

DROP TABLE IF EXISTS `system_event_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_event_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_event_logs_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_event_logs`
--

LOCK TABLES `system_event_logs` WRITE;
/*!40000 ALTER TABLE `system_event_logs` DISABLE KEYS */;
INSERT INTO `system_event_logs` VALUES (1,'error','ErrorException: Division by zero in D:\\OpenServer\\domains\\KPCENTR\\storage\\cms\\twig\\e8\\e8f637887379e62f48a7d029604cd504e435a5cd05602f8e2ffac40232ab7e65.php:56\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\storage\\cms\\twig\\e8\\e8f637887379e62f48a7d029604cd504e435a5cd05602f8e2ffac40232ab7e65.php(56): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(405): __TwigTemplate_dde93655be1c6d21498404333f4272de4bc084430749023fab6daecf8e24956b->doDisplay()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(378): Twig\\Template->displayWithErrorHandling()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(390): Twig\\Template->display()\n#4 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(435): Twig\\Template->render()\n#5 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#6 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#7 [internal function]: Cms\\Classes\\CmsController->run()\n#8 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#46 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#47 {main}\n\nNext Twig\\Error\\RuntimeError: An exception has been thrown during the rendering of a template (\"Division by zero\") in \"D:\\OpenServer\\domains\\KPCENTR/themes/kptheme/layouts/default.htm\" at line 13. in D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php:419\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(378): Twig\\Template->displayWithErrorHandling()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(390): Twig\\Template->display()\n#2 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(435): Twig\\Template->render()\n#3 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#4 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#5 [internal function]: Cms\\Classes\\CmsController->run()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#8 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#44 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#45 {main}',NULL,'2022-06-14 09:22:40','2022-06-14 09:22:40'),(2,'error','Twig\\Error\\SyntaxError: Unexpected character \";\" in \"D:\\OpenServer\\domains\\KPCENTR/themes/kptheme/pages/home.htm\" at line 234. in D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php:365\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(292): Twig\\Lexer->lexExpression()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(186): Twig\\Lexer->lexVar()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(542): Twig\\Lexer->tokenize()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(595): Twig\\Environment->tokenize()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(408): Twig\\Environment->compileSource()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(381): Twig\\Environment->loadClass()\n#6 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(424): Twig\\Environment->loadTemplate()\n#7 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#8 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#9 [internal function]: Cms\\Classes\\CmsController->run()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#48 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#49 {main}',NULL,'2022-06-14 09:35:39','2022-06-14 09:35:39'),(3,'error','Twig\\Error\\SyntaxError: Unexpected character \";\" in \"D:\\OpenServer\\domains\\KPCENTR/themes/kptheme/pages/home.htm\" at line 485. in D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php:365\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(292): Twig\\Lexer->lexExpression()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(186): Twig\\Lexer->lexVar()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(542): Twig\\Lexer->tokenize()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(595): Twig\\Environment->tokenize()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(408): Twig\\Environment->compileSource()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(381): Twig\\Environment->loadClass()\n#6 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(424): Twig\\Environment->loadTemplate()\n#7 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#8 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#9 [internal function]: Cms\\Classes\\CmsController->run()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#48 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#49 {main}',NULL,'2022-06-14 09:37:36','2022-06-14 09:37:36'),(4,'error','Twig\\Error\\SyntaxError: Unexpected character \";\" in \"D:\\OpenServer\\domains\\KPCENTR/themes/kptheme/pages/home.htm\" at line 497. in D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php:365\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(292): Twig\\Lexer->lexExpression()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(186): Twig\\Lexer->lexVar()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(542): Twig\\Lexer->tokenize()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(595): Twig\\Environment->tokenize()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(408): Twig\\Environment->compileSource()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(381): Twig\\Environment->loadClass()\n#6 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(424): Twig\\Environment->loadTemplate()\n#7 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#8 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#9 [internal function]: Cms\\Classes\\CmsController->run()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#48 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#49 {main}',NULL,'2022-06-14 09:38:01','2022-06-14 09:38:01'),(5,'error','Twig\\Error\\SyntaxError: Unexpected character \";\" in \"D:\\OpenServer\\domains\\KPCENTR/themes/kptheme/pages/home.htm\" at line 497. in D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php:365\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(292): Twig\\Lexer->lexExpression()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Lexer.php(186): Twig\\Lexer->lexVar()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(542): Twig\\Lexer->tokenize()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(595): Twig\\Environment->tokenize()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(408): Twig\\Environment->compileSource()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Environment.php(381): Twig\\Environment->loadClass()\n#6 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(424): Twig\\Environment->loadTemplate()\n#7 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#8 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#9 [internal function]: Cms\\Classes\\CmsController->run()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#48 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#49 {main}',NULL,'2022-06-14 09:38:26','2022-06-14 09:38:26'),(6,'error','Cms\\Classes\\CmsException: The partial \'blog\' is not found. in D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php:1030\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\twig\\Extension.php(102): Cms\\Classes\\Controller->renderPartial()\n#1 D:\\OpenServer\\domains\\KPCENTR\\storage\\cms\\twig\\49\\49c882e73dd981697b1d9e6c328a5ebb8fd83251e9cc347d9ae550212f1e1488.php(559): Cms\\Twig\\Extension->partialFunction()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(405): __TwigTemplate_4fc7f9b7bc963f0dbc2336c7f375bc71471ec1b5dadf8f69bd56649596c7f0f5->doDisplay()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(378): Twig\\Template->displayWithErrorHandling()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(390): Twig\\Template->display()\n#5 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(425): Twig\\Template->render()\n#6 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#7 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#8 [internal function]: Cms\\Classes\\CmsController->run()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#47 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#48 {main}\n\nNext Twig\\Error\\RuntimeError: An exception has been thrown during the rendering of a template (\"The partial \'blog\' is not found.\") in \"D:\\OpenServer\\domains\\KPCENTR/themes/kptheme/pages/home.htm\" at line 491. in D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php:419\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(378): Twig\\Template->displayWithErrorHandling()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\twig\\twig\\src\\Template.php(390): Twig\\Template->display()\n#2 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(425): Twig\\Template->render()\n#3 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\Controller.php(225): Cms\\Classes\\Controller->runPage()\n#4 D:\\OpenServer\\domains\\KPCENTR\\modules\\cms\\classes\\CmsController.php(50): Cms\\Classes\\Controller->run()\n#5 [internal function]: Cms\\Classes\\CmsController->run()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#8 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#11 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#26 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#29 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#30 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#31 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#32 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#44 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#45 {main}',NULL,'2022-06-16 08:44:45','2022-06-16 08:44:45'),(7,'error','Swift_TransportException: Expected response code 354 but got code \"503\", with message \"503 RCPT command expected\r\n\" in D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php:459\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(344): Swift_Transport_AbstractSmtpTransport->assertResponseCode()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\EsmtpTransport.php(305): Swift_Transport_AbstractSmtpTransport->executeCommand()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(392): Swift_Transport_EsmtpTransport->executeCommand()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(499): Swift_Transport_AbstractSmtpTransport->doDataCommand()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(518): Swift_Transport_AbstractSmtpTransport->doMailTransaction()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(206): Swift_Transport_AbstractSmtpTransport->sendTo()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(71): Swift_Transport_AbstractSmtpTransport->send()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(451): Swift_Mailer->send()\n#8 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Mail\\Mailer.php(115): Illuminate\\Mail\\Mailer->sendSwiftMessage()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): October\\Rain\\Mail\\Mailer->send()\n#10 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(170): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#11 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(129): Backend\\Models\\User->sendInvitation()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(167): Backend\\Models\\User->afterCreate()\n#13 [internal function]: October\\Rain\\Database\\Model->October\\Rain\\Database\\{closure}()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(233): call_user_func_array()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Concerns\\HasEvents.php(148): October\\Rain\\Events\\Dispatcher->fire()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(708): Illuminate\\Database\\Eloquent\\Model->fireModelEvent()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(550): Illuminate\\Database\\Eloquent\\Model->performInsert()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(760): Illuminate\\Database\\Eloquent\\Model->save()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(793): October\\Rain\\Database\\Model->saveInternal()\n#21 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(252): October\\Rain\\Database\\Model->save()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Concerns\\ManagesTransactions.php(29): Backend\\Behaviors\\FormController->Backend\\Behaviors\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\DatabaseManager.php(327): Illuminate\\Database\\Connection->transaction()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): Illuminate\\Database\\DatabaseManager->__call()\n#25 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(254): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#26 [internal function]: Backend\\Behaviors\\FormController->create_onSave()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Extension\\ExtendableTrait.php(414): call_user_func_array()\n#28 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(184): Backend\\Classes\\Controller->extendableCall()\n#29 [internal function]: Backend\\Classes\\Controller->__call()\n#30 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(620): call_user_func_array()\n#31 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(478): Backend\\Classes\\Controller->runAjaxHandler()\n#32 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(277): Backend\\Classes\\Controller->execAjaxHandlers()\n#33 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(165): Backend\\Classes\\Controller->run()\n#34 [internal function]: Backend\\Classes\\BackendController->run()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(131): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#48 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#49 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#50 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#51 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#52 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#53 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#54 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#55 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#56 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#57 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#58 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#59 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#60 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#61 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#62 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#63 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#64 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#65 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#66 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#67 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#68 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#69 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#70 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#71 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#72 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#73 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#74 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#75 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#76 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#77 {main}',NULL,'2022-07-06 08:29:07','2022-07-06 08:29:07'),(8,'error','Swift_TransportException: Expected response code 354 but got code \"503\", with message \"503 RCPT command expected\r\n\" in D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php:459\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(344): Swift_Transport_AbstractSmtpTransport->assertResponseCode()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\EsmtpTransport.php(305): Swift_Transport_AbstractSmtpTransport->executeCommand()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(392): Swift_Transport_EsmtpTransport->executeCommand()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(499): Swift_Transport_AbstractSmtpTransport->doDataCommand()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(518): Swift_Transport_AbstractSmtpTransport->doMailTransaction()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(206): Swift_Transport_AbstractSmtpTransport->sendTo()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(71): Swift_Transport_AbstractSmtpTransport->send()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(451): Swift_Mailer->send()\n#8 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Mail\\Mailer.php(115): Illuminate\\Mail\\Mailer->sendSwiftMessage()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): October\\Rain\\Mail\\Mailer->send()\n#10 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(170): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#11 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(129): Backend\\Models\\User->sendInvitation()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(167): Backend\\Models\\User->afterCreate()\n#13 [internal function]: October\\Rain\\Database\\Model->October\\Rain\\Database\\{closure}()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(233): call_user_func_array()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Concerns\\HasEvents.php(148): October\\Rain\\Events\\Dispatcher->fire()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(708): Illuminate\\Database\\Eloquent\\Model->fireModelEvent()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(550): Illuminate\\Database\\Eloquent\\Model->performInsert()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(760): Illuminate\\Database\\Eloquent\\Model->save()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(793): October\\Rain\\Database\\Model->saveInternal()\n#21 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(252): October\\Rain\\Database\\Model->save()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Concerns\\ManagesTransactions.php(29): Backend\\Behaviors\\FormController->Backend\\Behaviors\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\DatabaseManager.php(327): Illuminate\\Database\\Connection->transaction()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): Illuminate\\Database\\DatabaseManager->__call()\n#25 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(254): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#26 [internal function]: Backend\\Behaviors\\FormController->create_onSave()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Extension\\ExtendableTrait.php(414): call_user_func_array()\n#28 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(184): Backend\\Classes\\Controller->extendableCall()\n#29 [internal function]: Backend\\Classes\\Controller->__call()\n#30 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(620): call_user_func_array()\n#31 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(478): Backend\\Classes\\Controller->runAjaxHandler()\n#32 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(277): Backend\\Classes\\Controller->execAjaxHandlers()\n#33 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(165): Backend\\Classes\\Controller->run()\n#34 [internal function]: Backend\\Classes\\BackendController->run()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(131): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#48 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#49 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#50 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#51 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#52 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#53 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#54 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#55 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#56 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#57 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#58 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#59 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#60 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#61 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#62 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#63 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#64 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#65 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#66 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#67 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#68 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#69 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#70 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#71 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#72 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#73 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#74 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#75 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#76 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#77 {main}',NULL,'2022-07-06 08:29:58','2022-07-06 08:29:58'),(9,'error','Swift_TransportException: Expected response code 354 but got code \"503\", with message \"503 RCPT command expected\r\n\" in D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php:459\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(344): Swift_Transport_AbstractSmtpTransport->assertResponseCode()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\EsmtpTransport.php(305): Swift_Transport_AbstractSmtpTransport->executeCommand()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(392): Swift_Transport_EsmtpTransport->executeCommand()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(499): Swift_Transport_AbstractSmtpTransport->doDataCommand()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(518): Swift_Transport_AbstractSmtpTransport->doMailTransaction()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(206): Swift_Transport_AbstractSmtpTransport->sendTo()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(71): Swift_Transport_AbstractSmtpTransport->send()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(451): Swift_Mailer->send()\n#8 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Mail\\Mailer.php(115): Illuminate\\Mail\\Mailer->sendSwiftMessage()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Mail\\Mailer.php(181): October\\Rain\\Mail\\Mailer->send()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): October\\Rain\\Mail\\Mailer->sendTo()\n#11 D:\\OpenServer\\domains\\KPCENTR\\plugins\\rainlab\\user\\models\\User.php(524): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#12 D:\\OpenServer\\domains\\KPCENTR\\plugins\\rainlab\\user\\models\\User.php(284): RainLab\\User\\Models\\User->sendInvitation()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(167): RainLab\\User\\Models\\User->afterCreate()\n#14 [internal function]: October\\Rain\\Database\\Model->October\\Rain\\Database\\{closure}()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(233): call_user_func_array()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Concerns\\HasEvents.php(148): October\\Rain\\Events\\Dispatcher->fire()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(708): Illuminate\\Database\\Eloquent\\Model->fireModelEvent()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(550): Illuminate\\Database\\Eloquent\\Model->performInsert()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(760): Illuminate\\Database\\Eloquent\\Model->save()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(793): October\\Rain\\Database\\Model->saveInternal()\n#22 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(252): October\\Rain\\Database\\Model->save()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Concerns\\ManagesTransactions.php(29): Backend\\Behaviors\\FormController->Backend\\Behaviors\\{closure}()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\DatabaseManager.php(327): Illuminate\\Database\\Connection->transaction()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): Illuminate\\Database\\DatabaseManager->__call()\n#26 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(254): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#27 [internal function]: Backend\\Behaviors\\FormController->create_onSave()\n#28 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Extension\\ExtendableTrait.php(414): call_user_func_array()\n#29 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(184): Backend\\Classes\\Controller->extendableCall()\n#30 [internal function]: Backend\\Classes\\Controller->__call()\n#31 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(620): call_user_func_array()\n#32 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(478): Backend\\Classes\\Controller->runAjaxHandler()\n#33 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(277): Backend\\Classes\\Controller->execAjaxHandlers()\n#34 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(165): Backend\\Classes\\Controller->run()\n#35 [internal function]: Backend\\Classes\\BackendController->run()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(131): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#48 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#49 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#50 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#51 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#52 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#53 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#54 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#55 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#56 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#57 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#58 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#59 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#60 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#61 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#62 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#63 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#64 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#65 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#66 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#67 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#68 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#69 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#70 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#71 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#72 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#73 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#74 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#75 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#76 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#77 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#78 {main}',NULL,'2022-07-06 08:34:49','2022-07-06 08:34:49'),(10,'error','Swift_TransportException: Expected response code 354 but got code \"503\", with message \"503 RCPT command expected\r\n\" in D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php:459\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(344): Swift_Transport_AbstractSmtpTransport->assertResponseCode()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\EsmtpTransport.php(305): Swift_Transport_AbstractSmtpTransport->executeCommand()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(392): Swift_Transport_EsmtpTransport->executeCommand()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(499): Swift_Transport_AbstractSmtpTransport->doDataCommand()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(518): Swift_Transport_AbstractSmtpTransport->doMailTransaction()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(206): Swift_Transport_AbstractSmtpTransport->sendTo()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(71): Swift_Transport_AbstractSmtpTransport->send()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(451): Swift_Mailer->send()\n#8 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Mail\\Mailer.php(115): Illuminate\\Mail\\Mailer->sendSwiftMessage()\n#9 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): October\\Rain\\Mail\\Mailer->send()\n#10 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(170): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#11 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(129): Backend\\Models\\User->sendInvitation()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(167): Backend\\Models\\User->afterCreate()\n#13 [internal function]: October\\Rain\\Database\\Model->October\\Rain\\Database\\{closure}()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(233): call_user_func_array()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Concerns\\HasEvents.php(148): October\\Rain\\Events\\Dispatcher->fire()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(708): Illuminate\\Database\\Eloquent\\Model->fireModelEvent()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(550): Illuminate\\Database\\Eloquent\\Model->performInsert()\n#19 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(760): Illuminate\\Database\\Eloquent\\Model->save()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(793): October\\Rain\\Database\\Model->saveInternal()\n#21 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(252): October\\Rain\\Database\\Model->save()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Concerns\\ManagesTransactions.php(29): Backend\\Behaviors\\FormController->Backend\\Behaviors\\{closure}()\n#23 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\DatabaseManager.php(327): Illuminate\\Database\\Connection->transaction()\n#24 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): Illuminate\\Database\\DatabaseManager->__call()\n#25 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(254): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#26 [internal function]: Backend\\Behaviors\\FormController->create_onSave()\n#27 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Extension\\ExtendableTrait.php(414): call_user_func_array()\n#28 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(184): Backend\\Classes\\Controller->extendableCall()\n#29 [internal function]: Backend\\Classes\\Controller->__call()\n#30 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(620): call_user_func_array()\n#31 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(478): Backend\\Classes\\Controller->runAjaxHandler()\n#32 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(277): Backend\\Classes\\Controller->execAjaxHandlers()\n#33 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(165): Backend\\Classes\\Controller->run()\n#34 [internal function]: Backend\\Classes\\BackendController->run()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#39 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(131): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#48 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#49 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#50 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#51 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#52 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#53 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#54 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#55 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#56 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#57 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#58 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#59 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#60 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#61 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#62 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#63 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#64 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#65 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#66 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#67 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#68 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#69 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#70 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#71 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#72 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#73 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#74 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#75 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#76 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#77 {main}',NULL,'2022-07-06 08:41:56','2022-07-06 08:41:56'),(11,'error','Swift_TransportException: Connection could not be established with host smtp.mailgun.org :stream_socket_client(): unable to connect to tcp://smtp.mailgun.org:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.\r\n) in D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php:261\nStack trace:\n#0 [internal function]: Swift_Transport_StreamBuffer->{closure}()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(264): stream_socket_client()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(58): Swift_Transport_StreamBuffer->establishSocketConnection()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(143): Swift_Transport_StreamBuffer->initialize()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(65): Swift_Transport_AbstractSmtpTransport->start()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(451): Swift_Mailer->send()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Mail\\Mailer.php(115): Illuminate\\Mail\\Mailer->sendSwiftMessage()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): October\\Rain\\Mail\\Mailer->send()\n#8 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(170): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#9 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(129): Backend\\Models\\User->sendInvitation()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(167): Backend\\Models\\User->afterCreate()\n#11 [internal function]: October\\Rain\\Database\\Model->October\\Rain\\Database\\{closure}()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(233): call_user_func_array()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Concerns\\HasEvents.php(148): October\\Rain\\Events\\Dispatcher->fire()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(708): Illuminate\\Database\\Eloquent\\Model->fireModelEvent()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(550): Illuminate\\Database\\Eloquent\\Model->performInsert()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(760): Illuminate\\Database\\Eloquent\\Model->save()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(793): October\\Rain\\Database\\Model->saveInternal()\n#19 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(252): October\\Rain\\Database\\Model->save()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Concerns\\ManagesTransactions.php(29): Backend\\Behaviors\\FormController->Backend\\Behaviors\\{closure}()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\DatabaseManager.php(327): Illuminate\\Database\\Connection->transaction()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): Illuminate\\Database\\DatabaseManager->__call()\n#23 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(254): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#24 [internal function]: Backend\\Behaviors\\FormController->create_onSave()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Extension\\ExtendableTrait.php(414): call_user_func_array()\n#26 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(184): Backend\\Classes\\Controller->extendableCall()\n#27 [internal function]: Backend\\Classes\\Controller->__call()\n#28 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(620): call_user_func_array()\n#29 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(478): Backend\\Classes\\Controller->runAjaxHandler()\n#30 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(277): Backend\\Classes\\Controller->execAjaxHandlers()\n#31 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(165): Backend\\Classes\\Controller->run()\n#32 [internal function]: Backend\\Classes\\BackendController->run()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(131): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#48 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#49 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#50 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#51 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#52 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#53 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#54 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#55 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#56 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#57 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#58 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#59 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#60 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#61 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#62 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#63 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#64 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#65 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#66 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#67 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#68 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#69 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#70 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#71 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#72 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#73 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#74 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#75 {main}',NULL,'2022-07-11 09:50:01','2022-07-11 09:50:01'),(12,'error','Swift_TransportException: Connection could not be established with host mail.ee :stream_socket_client(): unable to connect to tcp://mail.ee:587 (No connection could be made because the target machine actively refused it.\r\n) in D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php:261\nStack trace:\n#0 [internal function]: Swift_Transport_StreamBuffer->{closure}()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(264): stream_socket_client()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(58): Swift_Transport_StreamBuffer->establishSocketConnection()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(143): Swift_Transport_StreamBuffer->initialize()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(65): Swift_Transport_AbstractSmtpTransport->start()\n#5 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(451): Swift_Mailer->send()\n#6 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Mail\\Mailer.php(115): Illuminate\\Mail\\Mailer->sendSwiftMessage()\n#7 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): October\\Rain\\Mail\\Mailer->send()\n#8 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(170): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#9 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\models\\User.php(129): Backend\\Models\\User->sendInvitation()\n#10 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(167): Backend\\Models\\User->afterCreate()\n#11 [internal function]: October\\Rain\\Database\\Model->October\\Rain\\Database\\{closure}()\n#12 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(233): call_user_func_array()\n#13 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Events\\Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch()\n#14 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Concerns\\HasEvents.php(148): October\\Rain\\Events\\Dispatcher->fire()\n#15 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(708): Illuminate\\Database\\Eloquent\\Model->fireModelEvent()\n#16 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Eloquent\\Model.php(550): Illuminate\\Database\\Eloquent\\Model->performInsert()\n#17 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(760): Illuminate\\Database\\Eloquent\\Model->save()\n#18 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Database\\Model.php(793): October\\Rain\\Database\\Model->saveInternal()\n#19 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(252): October\\Rain\\Database\\Model->save()\n#20 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\Concerns\\ManagesTransactions.php(29): Backend\\Behaviors\\FormController->Backend\\Behaviors\\{closure}()\n#21 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Database\\DatabaseManager.php(327): Illuminate\\Database\\Connection->transaction()\n#22 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Facades\\Facade.php(221): Illuminate\\Database\\DatabaseManager->__call()\n#23 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\behaviors\\FormController.php(254): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#24 [internal function]: Backend\\Behaviors\\FormController->create_onSave()\n#25 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Extension\\ExtendableTrait.php(414): call_user_func_array()\n#26 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(184): Backend\\Classes\\Controller->extendableCall()\n#27 [internal function]: Backend\\Classes\\Controller->__call()\n#28 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(620): call_user_func_array()\n#29 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(478): Backend\\Classes\\Controller->runAjaxHandler()\n#30 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\Controller.php(277): Backend\\Classes\\Controller->execAjaxHandlers()\n#31 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(165): Backend\\Classes\\Controller->run()\n#32 [internal function]: Backend\\Classes\\BackendController->run()\n#33 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php(54): call_user_func_array()\n#34 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()\n#35 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#36 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Route.php(169): Illuminate\\Routing\\Route->runController()\n#37 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(658): Illuminate\\Routing\\Route->run()\n#38 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#39 D:\\OpenServer\\domains\\KPCENTR\\modules\\backend\\classes\\BackendController.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#40 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(131): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#41 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#42 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Middleware\\SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#43 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#44 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#45 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\View\\Middleware\\ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#46 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#47 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#48 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Session\\Middleware\\StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#49 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle()\n#50 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#51 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#52 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#53 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#54 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Cookie\\Middleware\\EncryptCookies.php(68): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#55 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#56 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#57 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#58 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(660): Illuminate\\Pipeline\\Pipeline->then()\n#59 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack()\n#60 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Router.php(601): Illuminate\\Routing\\Router->runRoute()\n#61 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Router\\CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#62 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch()\n#63 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#64 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#65 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#66 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#67 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#68 D:\\OpenServer\\domains\\KPCENTR\\vendor\\october\\rain\\src\\Http\\Middleware\\TrustHosts.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#69 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(149): October\\Rain\\Http\\Middleware\\TrustHosts->handle()\n#70 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#71 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}()\n#72 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then()\n#73 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Http\\Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#74 D:\\OpenServer\\domains\\KPCENTR\\index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()\n#75 {main}',NULL,'2022-07-11 09:59:49','2022-07-11 09:59:49');
/*!40000 ALTER TABLE `system_event_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_files`
--

DROP TABLE IF EXISTS `system_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disk_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL,
  `content_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_files_field_index` (`field`),
  KEY `system_files_attachment_id_index` (`attachment_id`),
  KEY `system_files_attachment_type_index` (`attachment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_files`
--

LOCK TABLES `system_files` WRITE;
/*!40000 ALTER TABLE `system_files` DISABLE KEYS */;
INSERT INTO `system_files` VALUES (2,'62ab1dc6565a6318816544.jpg','photo5190650646926309956.jpg',108743,'image/jpeg',NULL,NULL,'featured_images','3','RainLab\\Blog\\Models\\Post',1,1,'2022-06-16 09:10:46','2022-06-16 09:42:38');
/*!40000 ALTER TABLE `system_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_layouts`
--

DROP TABLE IF EXISTS `system_mail_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_layouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_css` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_layouts`
--

LOCK TABLES `system_mail_layouts` WRITE;
/*!40000 ALTER TABLE `system_mail_layouts` DISABLE KEYS */;
INSERT INTO `system_mail_layouts` VALUES (1,'Default layout','default','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-default\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n\n        <!-- Header -->\n        {% partial \'header\' body %}\n            {{ subject|raw }}\n        {% endpartial %}\n\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n\n        <!-- Footer -->\n        {% partial \'footer\' body %}\n            &copy; {{ \"now\"|date(\"Y\") }} {{ appName }}. All rights reserved.\n        {% endpartial %}\n\n    </table>\n\n</body>\n</html>','{{ content|raw }}','@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}',1,NULL,'2022-05-17 07:12:18','2022-05-17 07:12:18'),(2,'System layout','system','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-system\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n\n                                        <!-- Subcopy -->\n                                        {% partial \'subcopy\' body %}\n                                            **This is an automatic message. Please do not reply to it.**\n                                        {% endpartial %}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n    </table>\n\n</body>\n</html>','{{ content|raw }}\n\n\n---\nThis is an automatic message. Please do not reply to it.','@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}',1,NULL,'2022-05-17 07:12:18','2022-05-17 07:12:18');
/*!40000 ALTER TABLE `system_mail_layouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_partials`
--

DROP TABLE IF EXISTS `system_mail_partials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_partials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_partials`
--

LOCK TABLES `system_mail_partials` WRITE;
/*!40000 ALTER TABLE `system_mail_partials` DISABLE KEYS */;
INSERT INTO `system_mail_partials` VALUES (1,'Header','header','<tr>\r\n    <td class=\"header\">\r\n        {% if url %}\r\n            <a href=\"{{ url }}\">\r\n                {{ body }}\r\n            </a>\r\n        {% else %}\r\n            <span>\r\n                {{ body }}\r\n            </span>\r\n        {% endif %}\r\n    </td>\r\n</tr>','*** {{ body|trim }} <{{ url }}>',0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(2,'Footer','footer','<tr>\r\n    <td>\r\n        <table class=\"footer\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\r\n            <tr>\r\n                <td class=\"content-cell\" align=\"center\">\r\n                    {{ body|md_safe }}\r\n                </td>\r\n            </tr>\r\n        </table>\r\n    </td>\r\n</tr>','-------------------\r\n{{ body|trim }}',0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(3,'Button','button','<table class=\"action\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\r\n    <tr>\r\n        <td align=\"center\">\r\n            <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                <tr>\r\n                    <td align=\"center\">\r\n                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                            <tr>\r\n                                <td>\r\n                                    <a href=\"{{ url }}\" class=\"button button-{{ type ?: \'primary\' }}\" target=\"_blank\">\r\n                                        {{ body }}\r\n                                    </a>\r\n                                </td>\r\n                            </tr>\r\n                        </table>\r\n                    </td>\r\n                </tr>\r\n            </table>\r\n        </td>\r\n    </tr>\r\n</table>','{{ body|trim }} <{{ url }}>',0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(4,'Panel','panel','<table class=\"panel break-all\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\r\n    <tr>\r\n        <td class=\"panel-content\">\r\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\r\n                <tr>\r\n                    <td class=\"panel-item\">\r\n                        {{ body|md_safe }}\r\n                    </td>\r\n                </tr>\r\n            </table>\r\n        </td>\r\n    </tr>\r\n</table>','{{ body|trim }}',0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(5,'Table','table','<div class=\"table\">\r\n    {{ body|md_safe }}\r\n</div>','{{ body|trim }}',0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(6,'Subcopy','subcopy','<table class=\"subcopy\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\r\n    <tr>\r\n        <td>\r\n            {{ body|md_safe }}\r\n        </td>\r\n    </tr>\r\n</table>','-----\r\n{{ body|trim }}',0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(7,'Promotion','promotion','<table class=\"promotion break-all\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\r\n    <tr>\r\n        <td align=\"center\">\r\n            {{ body|md_safe }}\r\n        </td>\r\n    </tr>\r\n</table>','{{ body|trim }}',0,'2022-07-06 08:52:17','2022-07-06 08:52:17');
/*!40000 ALTER TABLE `system_mail_partials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_templates`
--

DROP TABLE IF EXISTS `system_mail_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_id` int(11) DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_mail_templates_layout_id_index` (`layout_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_templates`
--

LOCK TABLES `system_mail_templates` WRITE;
/*!40000 ALTER TABLE `system_mail_templates` DISABLE KEYS */;
INSERT INTO `system_mail_templates` VALUES (1,'rainlab.forum::mail.topic_reply',NULL,NULL,NULL,NULL,1,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(2,'rainlab.forum::mail.member_report',NULL,NULL,NULL,NULL,1,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(3,'rainlab.user::mail.activate',NULL,'Activate a new user',NULL,NULL,1,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(4,'rainlab.user::mail.welcome',NULL,'User confirmed their account',NULL,NULL,1,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(5,'rainlab.user::mail.restore',NULL,'User requests a password reset',NULL,NULL,1,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(6,'rainlab.user::mail.new_user',NULL,'Notify admins of a new sign up',NULL,NULL,2,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(7,'rainlab.user::mail.reactivate',NULL,'User has reactivated their account',NULL,NULL,1,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(8,'rainlab.user::mail.invite',NULL,'Invite a new user to the website',NULL,NULL,1,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(9,'backend::mail.invite',NULL,'Invite new admin to the site',NULL,NULL,2,0,'2022-07-06 08:52:17','2022-07-06 08:52:17'),(10,'backend::mail.restore',NULL,'Reset an admin password',NULL,NULL,2,0,'2022-07-06 08:52:17','2022-07-06 08:52:17');
/*!40000 ALTER TABLE `system_mail_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_parameters`
--

DROP TABLE IF EXISTS `system_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_parameters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_index` (`namespace`,`group`,`item`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_parameters`
--

LOCK TABLES `system_parameters` WRITE;
/*!40000 ALTER TABLE `system_parameters` DISABLE KEYS */;
INSERT INTO `system_parameters` VALUES (1,'system','update','count','0'),(2,'system','core','hash','\"6819ec80bb4951db1139f26ca9238dbd\"'),(3,'system','core','build','\"476\"'),(4,'system','update','retry','1657108915'),(5,'cms','theme','active','\"rainlab-vanilla\"'),(6,'system','theme','history','{\"RainLab.Vanilla\":\"rainlab-vanilla\",\"RainLab.Relax\":\"rainlab-relax\"}');
/*!40000 ALTER TABLE `system_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_plugin_history`
--

DROP TABLE IF EXISTS `system_plugin_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_plugin_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_plugin_history_code_index` (`code`),
  KEY `system_plugin_history_type_index` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_plugin_history`
--

LOCK TABLES `system_plugin_history` WRITE;
/*!40000 ALTER TABLE `system_plugin_history` DISABLE KEYS */;
INSERT INTO `system_plugin_history` VALUES (1,'October.Demo','comment','1.0.1','First version of Demo','2022-05-17 07:12:18'),(2,'RainLab.Blog','script','1.0.1','create_posts_table.php','2022-06-16 08:04:26'),(3,'RainLab.Blog','script','1.0.1','create_categories_table.php','2022-06-16 08:04:26'),(4,'RainLab.Blog','script','1.0.1','seed_all_tables.php','2022-06-16 08:04:26'),(5,'RainLab.Blog','comment','1.0.1','Initialize plugin.','2022-06-16 08:04:26'),(6,'RainLab.Blog','comment','1.0.2','Added the processed HTML content column to the posts table.','2022-06-16 08:04:26'),(7,'RainLab.Blog','comment','1.0.3','Category component has been merged with Posts component.','2022-06-16 08:04:26'),(8,'RainLab.Blog','comment','1.0.4','Improvements to the Posts list management UI.','2022-06-16 08:04:26'),(9,'RainLab.Blog','comment','1.0.5','Removes the Author column from blog post list.','2022-06-16 08:04:26'),(10,'RainLab.Blog','comment','1.0.6','Featured images now appear in the Post component.','2022-06-16 08:04:26'),(11,'RainLab.Blog','comment','1.0.7','Added support for the Static Pages menus.','2022-06-16 08:04:26'),(12,'RainLab.Blog','comment','1.0.8','Added total posts to category list.','2022-06-16 08:04:26'),(13,'RainLab.Blog','comment','1.0.9','Added support for the Sitemap plugin.','2022-06-16 08:04:26'),(14,'RainLab.Blog','comment','1.0.10','Added permission to prevent users from seeing posts they did not create.','2022-06-16 08:04:26'),(15,'RainLab.Blog','comment','1.0.11','Deprecate \"idParam\" component property in favour of \"slug\" property.','2022-06-16 08:04:26'),(16,'RainLab.Blog','comment','1.0.12','Fixes issue where images cannot be uploaded caused by latest Markdown library.','2022-06-16 08:04:26'),(17,'RainLab.Blog','comment','1.0.13','Fixes problem with providing pages to Sitemap and Pages plugins.','2022-06-16 08:04:26'),(18,'RainLab.Blog','comment','1.0.14','Add support for CSRF protection feature added to core.','2022-06-16 08:04:26'),(19,'RainLab.Blog','comment','1.1.0','Replaced the Post editor with the new core Markdown editor.','2022-06-16 08:04:26'),(20,'RainLab.Blog','comment','1.1.1','Posts can now be imported and exported.','2022-06-16 08:04:26'),(21,'RainLab.Blog','comment','1.1.2','Posts are no longer visible if the published date has not passed.','2022-06-16 08:04:26'),(22,'RainLab.Blog','comment','1.1.3','Added a New Post shortcut button to the blog menu.','2022-06-16 08:04:26'),(23,'RainLab.Blog','script','1.2.0','categories_add_nested_fields.php','2022-06-16 08:04:27'),(24,'RainLab.Blog','comment','1.2.0','Categories now support nesting.','2022-06-16 08:04:27'),(25,'RainLab.Blog','comment','1.2.1','Post slugs now must be unique.','2022-06-16 08:04:27'),(26,'RainLab.Blog','comment','1.2.2','Fixes issue on new installs.','2022-06-16 08:04:27'),(27,'RainLab.Blog','comment','1.2.3','Minor user interface update.','2022-06-16 08:04:27'),(28,'RainLab.Blog','script','1.2.4','update_timestamp_nullable.php','2022-06-16 08:04:27'),(29,'RainLab.Blog','comment','1.2.4','Database maintenance. Updated all timestamp columns to be nullable.','2022-06-16 08:04:27'),(30,'RainLab.Blog','comment','1.2.5','Added translation support for blog posts.','2022-06-16 08:04:27'),(31,'RainLab.Blog','comment','1.2.6','The published field can now supply a time with the date.','2022-06-16 08:04:27'),(32,'RainLab.Blog','comment','1.2.7','Introduced a new RSS feed component.','2022-06-16 08:04:27'),(33,'RainLab.Blog','comment','1.2.8','Fixes issue with translated `content_html` attribute on blog posts.','2022-06-16 08:04:27'),(34,'RainLab.Blog','comment','1.2.9','Added translation support for blog categories.','2022-06-16 08:04:27'),(35,'RainLab.Blog','comment','1.2.10','Added translation support for post slugs.','2022-06-16 08:04:27'),(36,'RainLab.Blog','comment','1.2.11','Fixes bug where excerpt is not translated.','2022-06-16 08:04:27'),(37,'RainLab.Blog','comment','1.2.12','Description field added to category form.','2022-06-16 08:04:27'),(38,'RainLab.Blog','comment','1.2.13','Improved support for Static Pages menus, added a blog post and all blog posts.','2022-06-16 08:04:27'),(39,'RainLab.Blog','comment','1.2.14','Added post exception property to the post list component, useful for showing related posts.','2022-06-16 08:04:27'),(40,'RainLab.Blog','comment','1.2.15','Back-end navigation sort order updated.','2022-06-16 08:04:27'),(41,'RainLab.Blog','comment','1.2.16','Added `nextPost` and `previousPost` to the blog post component.','2022-06-16 08:04:27'),(42,'RainLab.Blog','comment','1.2.17','Improved the next and previous logic to sort by the published date.','2022-06-16 08:04:27'),(43,'RainLab.Blog','comment','1.2.18','Minor change to internals.','2022-06-16 08:04:27'),(44,'RainLab.Blog','comment','1.2.19','Improved support for Build 420+','2022-06-16 08:04:27'),(45,'RainLab.Blog','script','1.3.0','posts_add_metadata.php','2022-06-16 08:04:27'),(46,'RainLab.Blog','comment','1.3.0','Added metadata column for plugins to store data in','2022-06-16 08:04:27'),(47,'RainLab.Blog','comment','1.3.1','Fixed metadata column not being jsonable','2022-06-16 08:04:27'),(48,'RainLab.Blog','comment','1.3.2','Allow custom slug name for components, add 404 handling for missing blog posts, allow exporting of blog images.','2022-06-16 08:04:27'),(49,'RainLab.Blog','comment','1.3.3','Fixed \'excluded categories\' filter from being run when value is empty.','2022-06-16 08:04:27'),(50,'RainLab.Blog','comment','1.3.4','Allow post author to be specified. Improved translations.','2022-06-16 08:04:27'),(51,'RainLab.Blog','comment','1.3.5','Fixed missing user info from breaking initial seeder in migrations. Fixed a PostgreSQL issue with blog exports.','2022-06-16 08:04:27'),(52,'RainLab.Blog','comment','1.3.6','Improved French translations.','2022-06-16 08:04:27'),(53,'RainLab.Blog','comment','1.4.0','Stability improvements. Rollback custom slug names for components','2022-06-16 08:04:27'),(54,'RainLab.Blog','comment','1.4.1','Fixes potential security issue with unsafe Markdown. Allow blog bylines to be translated.','2022-06-16 08:04:27'),(55,'RainLab.Blog','comment','1.4.2','Fix 404 redirects for missing blog posts. Assign current category to the listed posts when using the Posts component on a page with the category parameter available.','2022-06-16 08:04:27'),(56,'RainLab.Blog','comment','1.4.3','Fixes incompatibility with locale switching when plugin is used in conjunction with the Translate plugin. Fixes undefined category error.','2022-06-16 08:04:27'),(57,'RainLab.Blog','comment','1.4.4','Rollback translated bylines, please move or override the default component markup instead.','2022-06-16 08:04:27'),(58,'RainLab.Blog','comment','1.5.0','Implement support for October CMS v2.0','2022-06-16 08:04:27'),(59,'RainLab.Blog','comment','1.5.1','Fixes interaction with Translate plugin','2022-06-16 08:04:27'),(60,'RainLab.Blog','comment','1.5.2','Minor styling improvements','2022-06-16 08:04:27'),(61,'RainLab.Blog','comment','1.5.3','Adds setting to use legacy markdown editor','2022-06-16 08:04:27'),(62,'RainLab.Blog','comment','1.5.4','Compatibility with October CMS v2.2','2022-06-16 08:04:27'),(63,'RainLab.Blog','comment','1.5.6','Compatibility with October CMS v3.0','2022-06-16 08:04:27'),(64,'RainLab.User','script','1.0.1','create_users_table.php','2022-07-06 08:22:53'),(65,'RainLab.User','script','1.0.1','create_throttle_table.php','2022-07-06 08:22:53'),(66,'RainLab.User','comment','1.0.1','Initialize plugin.','2022-07-06 08:22:53'),(67,'RainLab.User','comment','1.0.2','Seed tables.','2022-07-06 08:22:53'),(68,'RainLab.User','comment','1.0.3','Translated hard-coded text to language strings.','2022-07-06 08:22:53'),(69,'RainLab.User','comment','1.0.4','Improvements to user-interface for Location manager.','2022-07-06 08:22:53'),(70,'RainLab.User','comment','1.0.5','Added contact details for users.','2022-07-06 08:22:53'),(71,'RainLab.User','script','1.0.6','create_mail_blockers_table.php','2022-07-06 08:22:53'),(72,'RainLab.User','comment','1.0.6','Added Mail Blocker utility so users can block specific mail templates.','2022-07-06 08:22:53'),(73,'RainLab.User','comment','1.0.7','Add back-end Settings page.','2022-07-06 08:22:53'),(74,'RainLab.User','comment','1.0.8','Updated the Settings page.','2022-07-06 08:22:53'),(75,'RainLab.User','comment','1.0.9','Adds new welcome mail message for users and administrators.','2022-07-06 08:22:53'),(76,'RainLab.User','comment','1.0.10','Adds administrator-only activation mode.','2022-07-06 08:22:53'),(77,'RainLab.User','script','1.0.11','users_add_login_column.php','2022-07-06 08:22:53'),(78,'RainLab.User','comment','1.0.11','Users now have an optional login field that defaults to the email field.','2022-07-06 08:22:53'),(79,'RainLab.User','script','1.0.12','users_rename_login_to_username.php','2022-07-06 08:22:53'),(80,'RainLab.User','comment','1.0.12','Create a dedicated setting for choosing the login mode.','2022-07-06 08:22:53'),(81,'RainLab.User','comment','1.0.13','Minor fix to the Account sign in logic.','2022-07-06 08:22:53'),(82,'RainLab.User','comment','1.0.14','Minor improvements to the code.','2022-07-06 08:22:53'),(83,'RainLab.User','script','1.0.15','users_add_surname.php','2022-07-06 08:22:53'),(84,'RainLab.User','comment','1.0.15','Adds last name column to users table (surname).','2022-07-06 08:22:53'),(85,'RainLab.User','comment','1.0.16','Require permissions for settings page too.','2022-07-06 08:22:53'),(86,'RainLab.User','comment','1.1.0','Profile fields and Locations have been removed.','2022-07-06 08:22:53'),(87,'RainLab.User','script','1.1.1','create_user_groups_table.php','2022-07-06 08:22:53'),(88,'RainLab.User','script','1.1.1','seed_user_groups_table.php','2022-07-06 08:22:53'),(89,'RainLab.User','comment','1.1.1','Users can now be added to groups.','2022-07-06 08:22:53'),(90,'RainLab.User','comment','1.1.2','A raw URL can now be passed as the redirect property in the Account component.','2022-07-06 08:22:53'),(91,'RainLab.User','comment','1.1.3','Adds a super user flag to the users table, reserved for future use.','2022-07-06 08:22:53'),(92,'RainLab.User','comment','1.1.4','User list can be filtered by the group they belong to.','2022-07-06 08:22:53'),(93,'RainLab.User','comment','1.1.5','Adds a new permission to hide the User settings menu item.','2022-07-06 08:22:53'),(94,'RainLab.User','script','1.2.0','users_add_deleted_at.php','2022-07-06 08:22:53'),(95,'RainLab.User','comment','1.2.0','Users can now deactivate their own accounts.','2022-07-06 08:22:53'),(96,'RainLab.User','comment','1.2.1','New feature for checking if a user is recently active/online.','2022-07-06 08:22:53'),(97,'RainLab.User','comment','1.2.2','Add bulk action button to user list.','2022-07-06 08:22:53'),(98,'RainLab.User','comment','1.2.3','Included some descriptive paragraphs in the Reset Password component markup.','2022-07-06 08:22:53'),(99,'RainLab.User','comment','1.2.4','Added a checkbox for blocking all mail sent to the user.','2022-07-06 08:22:53'),(100,'RainLab.User','script','1.2.5','update_timestamp_nullable.php','2022-07-06 08:22:53'),(101,'RainLab.User','comment','1.2.5','Database maintenance. Updated all timestamp columns to be nullable.','2022-07-06 08:22:54'),(102,'RainLab.User','script','1.2.6','users_add_last_seen.php','2022-07-06 08:22:54'),(103,'RainLab.User','comment','1.2.6','Add a dedicated last seen column for users.','2022-07-06 08:22:54'),(104,'RainLab.User','comment','1.2.7','Minor fix to user timestamp attributes.','2022-07-06 08:22:54'),(105,'RainLab.User','comment','1.2.8','Add date range filter to users list. Introduced a logout event.','2022-07-06 08:22:54'),(106,'RainLab.User','comment','1.2.9','Add invitation mail for new accounts created in the back-end.','2022-07-06 08:22:54'),(107,'RainLab.User','script','1.3.0','users_add_guest_flag.php','2022-07-06 08:22:54'),(108,'RainLab.User','script','1.3.0','users_add_superuser_flag.php','2022-07-06 08:22:54'),(109,'RainLab.User','comment','1.3.0','Introduced guest user accounts.','2022-07-06 08:22:54'),(110,'RainLab.User','comment','1.3.1','User notification variables can now be extended.','2022-07-06 08:22:54'),(111,'RainLab.User','comment','1.3.2','Minor fix to the Auth::register method.','2022-07-06 08:22:54'),(112,'RainLab.User','comment','1.3.3','Allow prevention of concurrent user sessions via the user settings.','2022-07-06 08:22:54'),(113,'RainLab.User','comment','1.3.4','Added force secure protocol property to the account component.','2022-07-06 08:22:54'),(114,'RainLab.User','comment','1.4.0','The Notifications tab in User settings has been removed.','2022-07-06 08:22:54'),(115,'RainLab.User','comment','1.4.1','Added support for user impersonation.','2022-07-06 08:22:54'),(116,'RainLab.User','comment','1.4.2','Fixes security bug in Password Reset component.','2022-07-06 08:22:54'),(117,'RainLab.User','comment','1.4.3','Fixes session handling for AJAX requests.','2022-07-06 08:22:54'),(118,'RainLab.User','comment','1.4.4','Fixes bug where impersonation touches the last seen timestamp.','2022-07-06 08:22:54'),(119,'RainLab.User','comment','1.4.5','Added token fallback process to Account / Reset Password components when parameter is missing.','2022-07-06 08:22:54'),(120,'RainLab.User','comment','1.4.6','Fixes Auth::register method signature mismatch with core October CMS Auth library','2022-07-06 08:22:54'),(121,'RainLab.User','comment','1.4.7','Fixes redirect bug in Account component / Update translations and separate user and group management.','2022-07-06 08:22:54'),(122,'RainLab.User','comment','1.4.8','Fixes a bug where calling MailBlocker::removeBlock could remove all mail blocks for the user.','2022-07-06 08:22:54'),(123,'RainLab.User','comment','1.5.0','Required password length is now a minimum of 8 characters. Previous passwords will not be affected until the next password change.','2022-07-06 08:22:54'),(124,'RainLab.User','script','1.5.1','users_add_ip_address.php','2022-07-06 08:22:54'),(125,'RainLab.User','comment','1.5.1','User IP addresses are now logged. Introduce registration throttle.','2022-07-06 08:22:54'),(126,'RainLab.User','comment','1.5.2','Whitespace from usernames is now trimmed, allowed for username to be added to Reset Password mail templates.','2022-07-06 08:22:54'),(127,'RainLab.User','comment','1.5.3','Fixes a bug in the user update functionality if password is not changed. Added highlighting for banned users in user list.','2022-07-06 08:22:54'),(128,'RainLab.User','comment','1.5.4','Multiple translation improvements. Added view events to extend user preview and user listing toolbars.','2022-07-06 08:22:54'),(129,'RainLab.User','comment','1.5.5','Updated settings icon and description.','2022-07-06 08:22:54'),(130,'RainLab.User','comment','1.6.0','Apply persistence settings on activation and registration. Fixes last seen touched when impersonating. Fixes user suspension not clearing.','2022-07-06 08:22:54'),(131,'RainLab.User','comment','1.6.1','Adds component property for resetPage in ResetPassword component.','2022-07-06 08:22:54'),(132,'RainLab.User','comment','1.6.2','Improve support with October v3','2022-07-06 08:22:54'),(133,'RainLab.Forum','script','1.0.1','create_channels_table.php','2022-07-06 08:22:54'),(134,'RainLab.Forum','script','1.0.1','create_posts_table.php','2022-07-06 08:22:54'),(135,'RainLab.Forum','script','1.0.1','create_topics_table.php','2022-07-06 08:22:54'),(136,'RainLab.Forum','script','1.0.1','create_members_table.php','2022-07-06 08:22:54'),(137,'RainLab.Forum','script','1.0.1','seed_all_tables.php','2022-07-06 08:22:54'),(138,'RainLab.Forum','comment','1.0.1','First version of Forum','2022-07-06 08:22:54'),(139,'RainLab.Forum','script','1.0.2','create_topic_watches_table.php','2022-07-06 08:22:55'),(140,'RainLab.Forum','comment','1.0.2','Add unread flags to topics','2022-07-06 08:22:55'),(141,'RainLab.Forum','script','1.0.3','members_add_mod_and_ban.php','2022-07-06 08:22:55'),(142,'RainLab.Forum','comment','1.0.3','Users can now be made moderators or be banned','2022-07-06 08:22:55'),(143,'RainLab.Forum','script','1.0.4','channels_add_hidden_and_moderated.php','2022-07-06 08:22:55'),(144,'RainLab.Forum','comment','1.0.4','Channels can now be hidden or moderated','2022-07-06 08:22:55'),(145,'RainLab.Forum','script','1.0.5','add_embed_code.php','2022-07-06 08:22:55'),(146,'RainLab.Forum','comment','1.0.5','Introduced topic and channel embedding','2022-07-06 08:22:55'),(147,'RainLab.Forum','script','1.0.6','create_channel_watches_table.php','2022-07-06 08:22:55'),(148,'RainLab.Forum','comment','1.0.6','Add unread flags to channels','2022-07-06 08:22:55'),(149,'RainLab.Forum','script','1.0.7','create_topic_followers_table.php','2022-07-06 08:22:55'),(150,'RainLab.Forum','comment','1.0.7','Forum members can now follow topics','2022-07-06 08:22:55'),(151,'RainLab.Forum','comment','1.0.8','Added Channel name to the Topics component view','2022-07-06 08:22:55'),(152,'RainLab.Forum','comment','1.0.9','Updated the Settings page','2022-07-06 08:22:55'),(153,'RainLab.Forum','comment','1.0.10','Users can now report spammers who can be banned by moderators.','2022-07-06 08:22:55'),(154,'RainLab.Forum','comment','1.0.11','Users can now quote other posts.','2022-07-06 08:22:55'),(155,'RainLab.Forum','comment','1.0.12','Improve support for CDN asset hosting.','2022-07-06 08:22:55'),(156,'RainLab.Forum','comment','1.0.13','Fixes a bug where channels cannot be selected in the Embed component inspector.','2022-07-06 08:22:55'),(157,'RainLab.Forum','comment','1.0.14','Improve the pagination code used in the component default markup.','2022-07-06 08:22:55'),(158,'RainLab.Forum','comment','1.0.15','When a User is deleted, their Member profile and posts is also deleted.','2022-07-06 08:22:55'),(159,'RainLab.Forum','comment','1.0.16','Posting topics is now throttled allowing 3 new topics every 15 minutes.','2022-07-06 08:22:55'),(160,'RainLab.Forum','comment','1.0.17','Update channel reorder page to new system reordering feature.','2022-07-06 08:22:55'),(161,'RainLab.Forum','comment','1.0.18','Minor fix to embed topic component.','2022-07-06 08:22:55'),(162,'RainLab.Forum','script','1.0.19','update_timestamp_nullable.php','2022-07-06 08:22:55'),(163,'RainLab.Forum','comment','1.0.19','Database maintenance. Updated all timestamp columns to be nullable.','2022-07-06 08:22:55'),(164,'RainLab.Forum','script','1.1.0','drop_watches_tables.php','2022-07-06 08:22:55'),(165,'RainLab.Forum','comment','1.1.0','Major performance enhancements','2022-07-06 08:22:55'),(166,'RainLab.Forum','comment','1.1.1','Fixes bug throwing error when a forum topic has no posts.','2022-07-06 08:22:55'),(167,'RainLab.Forum','comment','1.1.2','Add button for administrators to purge all posts by a member.','2022-07-06 08:22:55'),(168,'RainLab.Forum','script','1.2.0','members_add_spam_guard.php','2022-07-06 08:22:55'),(169,'RainLab.Forum','comment','1.2.0','Added spam guarding features.','2022-07-06 08:22:55'),(170,'RainLab.Forum','comment','1.2.1','Made plugin compatible with PHP 7.3. Improved translations.','2022-07-06 08:22:55'),(171,'RainLab.Forum','comment','1.2.2','The default CSS can now be disabled for all components. Changed `getChannelSlugOptions` method in EmbedChannel component from protected to public.','2022-07-06 08:22:55'),(172,'RainLab.Pages','comment','1.0.1','Implemented the static pages management and the Static Page component.','2022-07-06 08:25:44'),(173,'RainLab.Pages','comment','1.0.2','Fixed the page preview URL.','2022-07-06 08:25:44'),(174,'RainLab.Pages','comment','1.0.3','Implemented menus.','2022-07-06 08:25:44'),(175,'RainLab.Pages','comment','1.0.4','Implemented the content block management and placeholder support.','2022-07-06 08:25:44'),(176,'RainLab.Pages','comment','1.0.5','Added support for the Sitemap plugin.','2022-07-06 08:25:44'),(177,'RainLab.Pages','comment','1.0.6','Minor updates to the internal API.','2022-07-06 08:25:44'),(178,'RainLab.Pages','comment','1.0.7','Added the Snippets feature.','2022-07-06 08:25:44'),(179,'RainLab.Pages','comment','1.0.8','Minor improvements to the code.','2022-07-06 08:25:44'),(180,'RainLab.Pages','comment','1.0.9','Fixes issue where Snippet tab is missing from the Partials form.','2022-07-06 08:25:44'),(181,'RainLab.Pages','comment','1.0.10','Add translations for various locales.','2022-07-06 08:25:44'),(182,'RainLab.Pages','comment','1.0.11','Fixes issue where placeholders tabs were missing from Page form.','2022-07-06 08:25:44'),(183,'RainLab.Pages','comment','1.0.12','Implement Media Manager support.','2022-07-06 08:25:44'),(184,'RainLab.Pages','script','1.1.0','snippets_rename_viewbag_properties.php','2022-07-06 08:25:44'),(185,'RainLab.Pages','comment','1.1.0','Adds meta title and description to pages. Adds |staticPage filter.','2022-07-06 08:25:44'),(186,'RainLab.Pages','comment','1.1.1','Add support for Syntax Fields.','2022-07-06 08:25:44'),(187,'RainLab.Pages','comment','1.1.2','Static Breadcrumbs component now respects the hide from navigation setting.','2022-07-06 08:25:44'),(188,'RainLab.Pages','comment','1.1.3','Minor back-end styling fix.','2022-07-06 08:25:44'),(189,'RainLab.Pages','comment','1.1.4','Minor fix to the StaticPage component API.','2022-07-06 08:25:44'),(190,'RainLab.Pages','comment','1.1.5','Fixes bug when using syntax fields.','2022-07-06 08:25:44'),(191,'RainLab.Pages','comment','1.1.6','Minor styling fix to the back-end UI.','2022-07-06 08:25:45'),(192,'RainLab.Pages','comment','1.1.7','Improved menu item form to include CSS class, open in a new window and hidden flag.','2022-07-06 08:25:45'),(193,'RainLab.Pages','comment','1.1.8','Improved the output of snippet partials when saved.','2022-07-06 08:25:45'),(194,'RainLab.Pages','comment','1.1.9','Minor update to snippet inspector internal API.','2022-07-06 08:25:45'),(195,'RainLab.Pages','comment','1.1.10','Fixes a bug where selecting a layout causes permanent unsaved changes.','2022-07-06 08:25:45'),(196,'RainLab.Pages','comment','1.1.11','Add support for repeater syntax field.','2022-07-06 08:25:45'),(197,'RainLab.Pages','comment','1.2.0','Added support for translations, UI updates.','2022-07-06 08:25:45'),(198,'RainLab.Pages','comment','1.2.1','Use nice titles when listing the content files.','2022-07-06 08:25:45'),(199,'RainLab.Pages','comment','1.2.2','Minor styling update.','2022-07-06 08:25:45'),(200,'RainLab.Pages','comment','1.2.3','Snippets can now be moved by dragging them.','2022-07-06 08:25:45'),(201,'RainLab.Pages','comment','1.2.4','Fixes a bug where the cursor is misplaced when editing text files.','2022-07-06 08:25:45'),(202,'RainLab.Pages','comment','1.2.5','Fixes a bug where the parent page is lost upon changing a page layout.','2022-07-06 08:25:45'),(203,'RainLab.Pages','comment','1.2.6','Shared view variables are now passed to static pages.','2022-07-06 08:25:45'),(204,'RainLab.Pages','comment','1.2.7','Fixes issue with duplicating properties when adding multiple snippets on the same page.','2022-07-06 08:25:45'),(205,'RainLab.Pages','comment','1.2.8','Fixes a bug where creating a content block without extension doesn\'t save the contents to file.','2022-07-06 08:25:45'),(206,'RainLab.Pages','comment','1.2.9','Add conditional support for translating page URLs.','2022-07-06 08:25:45'),(207,'RainLab.Pages','comment','1.2.10','Streamline generation of URLs to use the new Cms::url helper.','2022-07-06 08:25:45'),(208,'RainLab.Pages','comment','1.2.11','Implements repeater usage with translate plugin.','2022-07-06 08:25:45'),(209,'RainLab.Pages','comment','1.2.12','Fixes minor issue when using snippets and switching the application locale.','2022-07-06 08:25:45'),(210,'RainLab.Pages','comment','1.2.13','Fixes bug when AJAX is used on a page that does not yet exist.','2022-07-06 08:25:45'),(211,'RainLab.Pages','comment','1.2.14','Add theme logging support for changes made to menus.','2022-07-06 08:25:45'),(212,'RainLab.Pages','comment','1.2.15','Back-end navigation sort order updated.','2022-07-06 08:25:45'),(213,'RainLab.Pages','comment','1.2.16','Fixes a bug when saving a template that has been modified outside of the CMS (mtime mismatch).','2022-07-06 08:25:45'),(214,'RainLab.Pages','comment','1.2.17','Changes locations of custom fields to secondary tabs instead of the primary Settings area. New menu search ability on adding menu items','2022-07-06 08:25:45'),(215,'RainLab.Pages','comment','1.2.18','Fixes cache-invalidation issues when RainLab.Translate is not installed. Added Greek & Simplified Chinese translations. Removed deprecated calls. Allowed saving HTML in snippet properties. Added support for the MediaFinder in menu items.','2022-07-06 08:25:45'),(216,'RainLab.Pages','comment','1.2.19','Catch exception with corrupted menu file.','2022-07-06 08:25:45'),(217,'RainLab.Pages','comment','1.2.20','StaticMenu component now exposes menuName property; added pages.menu.referencesGenerated event.','2022-07-06 08:25:45'),(218,'RainLab.Pages','comment','1.2.21','Fixes a bug where last Static Menu item cannot be deleted. Improved Persian, Slovak and Turkish translations.','2022-07-06 08:25:45'),(219,'RainLab.Pages','comment','1.3.0','Added support for using Database-driven Themes when enabled in the CMS configuration.','2022-07-06 08:25:45'),(220,'RainLab.Pages','comment','1.3.1','Added ChildPages Component, prevent hidden pages from being returned via menu item resolver.','2022-07-06 08:25:45'),(221,'RainLab.Pages','comment','1.3.2','Fixes error when creating a subpage whose parent has no layout set.','2022-07-06 08:25:45'),(222,'RainLab.Pages','comment','1.3.3','Improves user experience for users with only partial access through permissions','2022-07-06 08:25:45'),(223,'RainLab.Pages','comment','1.3.4','Fix error where large menus were being truncated due to the PHP \"max_input_vars\" configuration value. Improved Slovenian translation.','2022-07-06 08:25:45'),(224,'RainLab.Pages','comment','1.3.5','Minor fix to bust the browser cache for JS assets. Prevent duplicate property fields in snippet inspector.','2022-07-06 08:25:45'),(225,'RainLab.Pages','comment','1.3.6','ChildPages component now displays localized page titles from Translate plugin.','2022-07-06 08:25:45'),(226,'RainLab.Pages','comment','1.3.7','Adds MenuPicker formwidget. Adds future support for v2.0 of October CMS.','2022-07-06 08:25:45'),(227,'RainLab.Pages','comment','1.4.0','Fixes bug when adding menu items in October CMS v2.0.','2022-07-06 08:25:45'),(228,'RainLab.Pages','comment','1.4.1','Fixes support for configuration values.','2022-07-06 08:25:45'),(229,'RainLab.Pages','comment','1.4.3','Fixes page deletion is newer platform builds.','2022-07-06 08:25:45'),(230,'RainLab.Pages','comment','1.4.4','Disable touch device detection','2022-07-06 08:25:45'),(231,'RainLab.Pages','comment','1.4.5','Minor styling improvements','2022-07-06 08:25:45'),(232,'RainLab.Pages','comment','1.4.6','Minor styling improvements','2022-07-06 08:25:45'),(233,'RainLab.Pages','comment','1.4.7','Minor layout fix in the Page editor','2022-07-06 08:25:45'),(234,'RainLab.Pages','comment','1.4.8','Fixes rich editor usage inside repeaters. Adds getProcessedMarkup event.','2022-07-06 08:25:45'),(235,'RainLab.Pages','comment','1.4.9','Fixes a lifecycle issue when switching the page layout.','2022-07-06 08:25:45'),(236,'RainLab.Pages','comment','1.4.10','Fixes maintenance mode when using static pages.','2022-07-06 08:25:45'),(237,'RainLab.Pages','comment','1.4.11','Adds type hidden to content placeholders.','2022-07-06 08:25:45'),(238,'RainLab.Pages','comment','1.4.12','Improve support with October v2.2','2022-07-06 08:25:45'),(239,'RainLab.Pages','comment','1.5.0','Improve support with October v3.0','2022-07-06 08:25:45'),(240,'RainLab.Pages','comment','1.5.4','Compatibility updates','2022-07-06 08:25:45');
/*!40000 ALTER TABLE `system_plugin_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_plugin_versions`
--

DROP TABLE IF EXISTS `system_plugin_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_plugin_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_frozen` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `system_plugin_versions_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_plugin_versions`
--

LOCK TABLES `system_plugin_versions` WRITE;
/*!40000 ALTER TABLE `system_plugin_versions` DISABLE KEYS */;
INSERT INTO `system_plugin_versions` VALUES (1,'October.Demo','1.0.1','2022-05-17 07:12:18',1,1),(2,'RainLab.Blog','1.5.6','2022-06-16 08:04:27',0,0),(3,'RainLab.User','1.6.2','2022-07-06 08:22:54',0,0),(4,'RainLab.Forum','1.2.2','2022-07-06 08:22:55',0,0),(5,'RainLab.Pages','1.5.4','2022-07-06 08:25:45',0,0);
/*!40000 ALTER TABLE `system_plugin_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_request_logs`
--

DROP TABLE IF EXISTS `system_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_request_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_request_logs`
--

LOCK TABLES `system_request_logs` WRITE;
/*!40000 ALTER TABLE `system_request_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_request_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_revisions`
--

DROP TABLE IF EXISTS `system_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_revisions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cast` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`),
  KEY `system_revisions_user_id_index` (`user_id`),
  KEY `system_revisions_field_index` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_revisions`
--

LOCK TABLES `system_revisions` WRITE;
/*!40000 ALTER TABLE `system_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_settings_item_index` (`item`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'cms_maintenance_settings','{\"is_enabled\":\"1\",\"cms_page\":\"404.htm\",\"theme_map\":{\"demo\":\"404.htm\"}}'),(2,'rainlab_blog_settings','{\"show_all_posts\":\"1\",\"use_legacy_editor\":\"1\"}'),(3,'user_settings','{\"require_activation\":\"1\",\"activate_mode\":\"admin\",\"use_throttle\":\"1\",\"block_persistence\":\"0\",\"allow_registration\":\"0\",\"login_attribute\":\"username\",\"remember_login\":\"always\",\"use_register_throttle\":\"0\"}'),(4,'system_mail_settings','{\"send_mode\":\"smtp\",\"sender_name\":\"OctoberCMS\",\"sender_email\":\"kpcentr@mail.ee\",\"sendmail_path\":\"\\/usr\\/sbin\\/sendmail -bs\",\"smtp_address\":\"mail.ee\",\"smtp_port\":\"587\",\"smtp_user\":\"kpcentr@mail.ee\",\"smtp_password\":\"kpcentr1234\",\"smtp_authorization\":\"1\",\"smtp_encryption\":\"tls\",\"mailgun_domain\":\"\",\"mailgun_secret\":\"\",\"mandrill_secret\":\"\",\"ses_key\":\"\",\"ses_secret\":\"\",\"ses_region\":\"\",\"sparkpost_secret\":\"\"}');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_groups_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES (1,'Guest','guest','Default group for guest users.','2022-07-06 08:22:53','2022-07-06 08:22:53'),(2,'Registered','registered','Default group for registered users.','2022-07-06 08:22:53','2022-07-06 08:22:53');
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_throttle`
--

DROP TABLE IF EXISTS `user_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_throttle_user_id_index` (`user_id`),
  KEY `user_throttle_ip_address_index` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_throttle`
--

LOCK TABLES `user_throttle` WRITE;
/*!40000 ALTER TABLE `user_throttle` DISABLE KEYS */;
INSERT INTO `user_throttle` VALUES (1,2,NULL,0,NULL,0,NULL,0,NULL);
/*!40000 ALTER TABLE `user_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  `created_ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_login_unique` (`username`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`),
  KEY `users_login_index` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'uuu','bondyuk.a.g@gmail.com','$2y$10$e1Q8j1N571VuNNohoL3Av.6vLf66sg5vEZGVKywKOSUk5F/tANmge',NULL,NULL,NULL,NULL,1,'2022-07-06 08:54:30',NULL,'2022-07-06 08:54:09','2022-07-06 08:54:30','uuu','bbb',NULL,NULL,0,0,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`user_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (2,1);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-11 16:02:51
