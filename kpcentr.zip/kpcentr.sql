-- MariaDB dump 10.19  Distrib 10.5.11-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: kpcentr
-- ------------------------------------------------------
-- Server version	10.5.11-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_access_log`
--

DROP TABLE IF EXISTS `backend_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_access_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_access_log`
--

LOCK TABLES `backend_access_log` WRITE;
/*!40000 ALTER TABLE `backend_access_log` DISABLE KEYS */;
INSERT INTO `backend_access_log` VALUES (1,1,'127.0.0.1','2022-07-19 05:35:25','2022-07-19 05:35:25');
/*!40000 ALTER TABLE `backend_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_groups`
--

DROP TABLE IF EXISTS `backend_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_new_user_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`),
  KEY `code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_groups`
--

LOCK TABLES `backend_user_groups` WRITE;
/*!40000 ALTER TABLE `backend_user_groups` DISABLE KEYS */;
INSERT INTO `backend_user_groups` VALUES (1,'Owners','2022-07-19 05:35:06','2022-07-19 05:35:06','owners','Default group for website owners.',0);
/*!40000 ALTER TABLE `backend_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_preferences`
--

DROP TABLE IF EXISTS `backend_user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_item_index` (`user_id`,`namespace`,`group`,`item`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_preferences`
--

LOCK TABLES `backend_user_preferences` WRITE;
/*!40000 ALTER TABLE `backend_user_preferences` DISABLE KEYS */;
INSERT INTO `backend_user_preferences` VALUES (1,1,'backend','backend','preferences','{\"locale\":\"ru\",\"fallback_locale\":\"en\",\"timezone\":\"Europe\\/Kiev\",\"editor_font_size\":\"12\",\"editor_word_wrap\":\"fluid\",\"editor_code_folding\":\"manual\",\"editor_tab_size\":\"4\",\"editor_theme\":\"twilight\",\"editor_show_invisibles\":\"0\",\"editor_highlight_active_line\":\"1\",\"editor_use_hard_tabs\":\"0\",\"editor_show_gutter\":\"1\",\"editor_auto_closing\":\"0\",\"editor_autocompletion\":\"manual\",\"editor_enable_snippets\":\"0\",\"editor_display_indent_guides\":\"0\",\"editor_show_print_margin\":\"0\",\"user_id\":1}');
/*!40000 ALTER TABLE `backend_user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_roles`
--

DROP TABLE IF EXISTS `backend_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_unique` (`name`),
  KEY `role_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_roles`
--

LOCK TABLES `backend_user_roles` WRITE;
/*!40000 ALTER TABLE `backend_user_roles` DISABLE KEYS */;
INSERT INTO `backend_user_roles` VALUES (1,'Publisher','publisher','Site editor with access to publishing tools.','',1,'2022-07-19 05:35:06','2022-07-19 05:35:06'),(2,'Developer','developer','Site administrator with access to developer tools.','',1,'2022-07-19 05:35:06','2022-07-19 05:35:06');
/*!40000 ALTER TABLE `backend_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_throttle`
--

DROP TABLE IF EXISTS `backend_user_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backend_user_throttle_user_id_index` (`user_id`),
  KEY `backend_user_throttle_ip_address_index` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_throttle`
--

LOCK TABLES `backend_user_throttle` WRITE;
/*!40000 ALTER TABLE `backend_user_throttle` DISABLE KEYS */;
INSERT INTO `backend_user_throttle` VALUES (1,1,'127.0.0.1',0,NULL,0,NULL,0,NULL);
/*!40000 ALTER TABLE `backend_user_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_users`
--

DROP TABLE IF EXISTS `backend_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_unique` (`login`),
  UNIQUE KEY `email_unique` (`email`),
  KEY `act_code_index` (`activation_code`),
  KEY `reset_code_index` (`reset_password_code`),
  KEY `admin_role_index` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_users`
--

LOCK TABLES `backend_users` WRITE;
/*!40000 ALTER TABLE `backend_users` DISABLE KEYS */;
INSERT INTO `backend_users` VALUES (1,'','','admin','bbb@gmail.com','$2y$10$hqeFIJnx3osrxrS/JCZdF.7COMaDnrOrs9dfa3KntkCEYbrS8m/sa',NULL,'$2y$10$1Kp9AnbZKoLZsHyDWjpvz.Lx3UsyTDjM3g2.IErCx89CjsaeSS1gm',NULL,'',1,2,NULL,'2022-07-19 05:35:25','2022-07-19 05:35:06','2022-07-19 05:35:25',NULL,1);
/*!40000 ALTER TABLE `backend_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_users_groups`
--

DROP TABLE IF EXISTS `backend_users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`user_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_users_groups`
--

LOCK TABLES `backend_users_groups` WRITE;
/*!40000 ALTER TABLE `backend_users_groups` DISABLE KEYS */;
INSERT INTO `backend_users_groups` VALUES (1,1);
/*!40000 ALTER TABLE `backend_users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_data`
--

DROP TABLE IF EXISTS `cms_theme_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_data_theme_index` (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_data`
--

LOCK TABLES `cms_theme_data` WRITE;
/*!40000 ALTER TABLE `cms_theme_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_logs`
--

DROP TABLE IF EXISTS `cms_theme_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_logs_type_index` (`type`),
  KEY `cms_theme_logs_theme_index` (`theme`),
  KEY `cms_theme_logs_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_logs`
--

LOCK TABLES `cms_theme_logs` WRITE;
/*!40000 ALTER TABLE `cms_theme_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_templates`
--

DROP TABLE IF EXISTS `cms_theme_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(10) unsigned NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_templates_source_index` (`source`),
  KEY `cms_theme_templates_path_index` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_templates`
--

LOCK TABLES `cms_theme_templates` WRITE;
/*!40000 ALTER TABLE `cms_theme_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deferred_bindings`
--

DROP TABLE IF EXISTS `deferred_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deferred_bindings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `master_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `master_field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pivot_data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_bind` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deferred_bindings_master_type_index` (`master_type`),
  KEY `deferred_bindings_master_field_index` (`master_field`),
  KEY `deferred_bindings_slave_type_index` (`slave_type`),
  KEY `deferred_bindings_slave_id_index` (`slave_id`),
  KEY `deferred_bindings_session_key_index` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deferred_bindings`
--

LOCK TABLES `deferred_bindings` WRITE;
/*!40000 ALTER TABLE `deferred_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `deferred_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2013_10_01_000001_Db_Deferred_Bindings',1),(2,'2013_10_01_000002_Db_System_Files',1),(3,'2013_10_01_000003_Db_System_Plugin_Versions',1),(4,'2013_10_01_000004_Db_System_Plugin_History',1),(5,'2013_10_01_000005_Db_System_Settings',1),(6,'2013_10_01_000006_Db_System_Parameters',1),(7,'2013_10_01_000007_Db_System_Add_Disabled_Flag',1),(8,'2013_10_01_000008_Db_System_Mail_Templates',1),(9,'2013_10_01_000009_Db_System_Mail_Layouts',1),(10,'2014_10_01_000010_Db_Jobs',1),(11,'2014_10_01_000011_Db_System_Event_Logs',1),(12,'2014_10_01_000012_Db_System_Request_Logs',1),(13,'2014_10_01_000013_Db_System_Sessions',1),(14,'2015_10_01_000014_Db_System_Mail_Layout_Rename',1),(15,'2015_10_01_000015_Db_System_Add_Frozen_Flag',1),(16,'2015_10_01_000016_Db_Cache',1),(17,'2015_10_01_000017_Db_System_Revisions',1),(18,'2015_10_01_000018_Db_FailedJobs',1),(19,'2016_10_01_000019_Db_System_Plugin_History_Detail_Text',1),(20,'2016_10_01_000020_Db_System_Timestamp_Fix',1),(21,'2017_08_04_121309_Db_Deferred_Bindings_Add_Index_Session',1),(22,'2017_10_01_000021_Db_System_Sessions_Update',1),(23,'2017_10_01_000022_Db_Jobs_FailedJobs_Update',1),(24,'2017_10_01_000023_Db_System_Mail_Partials',1),(25,'2017_10_23_000024_Db_System_Mail_Layouts_Add_Options_Field',1),(26,'2021_10_01_000025_Db_Add_Pivot_Data_To_Deferred_Bindings',1),(27,'2013_10_01_000001_Db_Backend_Users',2),(28,'2013_10_01_000002_Db_Backend_User_Groups',2),(29,'2013_10_01_000003_Db_Backend_Users_Groups',2),(30,'2013_10_01_000004_Db_Backend_User_Throttle',2),(31,'2014_01_04_000005_Db_Backend_User_Preferences',2),(32,'2014_10_01_000006_Db_Backend_Access_Log',2),(33,'2014_10_01_000007_Db_Backend_Add_Description_Field',2),(34,'2015_10_01_000008_Db_Backend_Add_Superuser_Flag',2),(35,'2016_10_01_000009_Db_Backend_Timestamp_Fix',2),(36,'2017_10_01_000010_Db_Backend_User_Roles',2),(37,'2018_12_16_000011_Db_Backend_Add_Deleted_At',2),(38,'2014_10_01_000001_Db_Cms_Theme_Data',3),(39,'2016_10_01_000002_Db_Cms_Timestamp_Fix',3),(40,'2017_10_01_000003_Db_Cms_Theme_Logs',3),(41,'2018_11_01_000001_Db_Cms_Theme_Templates',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_activity` int(11) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_event_logs`
--

DROP TABLE IF EXISTS `system_event_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_event_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_event_logs_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_event_logs`
--

LOCK TABLES `system_event_logs` WRITE;
/*!40000 ALTER TABLE `system_event_logs` DISABLE KEYS */;
INSERT INTO `system_event_logs` VALUES (1,'error','Symfony\\Component\\Console\\Exception\\NamespaceNotFoundException: There are no commands defined in the \"clear\" namespace. in D:\\OpenServer\\domains\\KPCENTR\\vendor\\symfony\\console\\Application.php:604\nStack trace:\n#0 D:\\OpenServer\\domains\\KPCENTR\\vendor\\symfony\\console\\Application.php(657): Symfony\\Component\\Console\\Application->findNamespace()\n#1 D:\\OpenServer\\domains\\KPCENTR\\vendor\\symfony\\console\\Application.php(237): Symfony\\Component\\Console\\Application->find()\n#2 D:\\OpenServer\\domains\\KPCENTR\\vendor\\symfony\\console\\Application.php(149): Symfony\\Component\\Console\\Application->doRun()\n#3 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run()\n#4 D:\\OpenServer\\domains\\KPCENTR\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(131): Illuminate\\Console\\Application->run()\n#5 D:\\OpenServer\\domains\\KPCENTR\\artisan(35): Illuminate\\Foundation\\Console\\Kernel->handle()\n#6 {main}',NULL,'2022-07-19 10:59:06','2022-07-19 10:59:06');
/*!40000 ALTER TABLE `system_event_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_files`
--

DROP TABLE IF EXISTS `system_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disk_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL,
  `content_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_files_field_index` (`field`),
  KEY `system_files_attachment_id_index` (`attachment_id`),
  KEY `system_files_attachment_type_index` (`attachment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_files`
--

LOCK TABLES `system_files` WRITE;
/*!40000 ALTER TABLE `system_files` DISABLE KEYS */;
INSERT INTO `system_files` VALUES (1,'62d68d85d9609042197897.jpg','photo_2022-07-19_08-57-43 (2).jpg',177364,'image/jpeg',NULL,NULL,'featured_images','2','Winter\\Blog\\Models\\Post',1,1,'2022-07-19 07:55:01','2022-07-19 07:55:26');
/*!40000 ALTER TABLE `system_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_layouts`
--

DROP TABLE IF EXISTS `system_mail_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_layouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_css` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_layouts`
--

LOCK TABLES `system_mail_layouts` WRITE;
/*!40000 ALTER TABLE `system_mail_layouts` DISABLE KEYS */;
INSERT INTO `system_mail_layouts` VALUES (1,'Default layout','default','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-default\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n\n        <!-- Header -->\n        {% partial \'header\' body %}\n            {{ subject|raw }}\n        {% endpartial %}\n\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n\n        <!-- Footer -->\n        {% partial \'footer\' body %}\n            &copy; {{ \"now\"|date(\"Y\") }} {{ appName }}. All rights reserved.\n        {% endpartial %}\n\n    </table>\n\n</body>\n</html>','{{ content|raw }}','@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}',1,NULL,'2022-07-19 05:35:06','2022-07-19 05:35:06'),(2,'System layout','system','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-system\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n\n                                        <!-- Subcopy -->\n                                        {% partial \'subcopy\' body %}\n                                            **This is an automatic message. Please do not reply to it.**\n                                        {% endpartial %}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n    </table>\n\n</body>\n</html>','{{ content|raw }}\n\n\n---\nThis is an automatic message. Please do not reply to it.','@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}',1,NULL,'2022-07-19 05:35:06','2022-07-19 05:35:06');
/*!40000 ALTER TABLE `system_mail_layouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_partials`
--

DROP TABLE IF EXISTS `system_mail_partials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_partials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_partials`
--

LOCK TABLES `system_mail_partials` WRITE;
/*!40000 ALTER TABLE `system_mail_partials` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_mail_partials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_templates`
--

DROP TABLE IF EXISTS `system_mail_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_id` int(11) DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_mail_templates_layout_id_index` (`layout_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_templates`
--

LOCK TABLES `system_mail_templates` WRITE;
/*!40000 ALTER TABLE `system_mail_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_mail_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_parameters`
--

DROP TABLE IF EXISTS `system_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_parameters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_index` (`namespace`,`group`,`item`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_parameters`
--

LOCK TABLES `system_parameters` WRITE;
/*!40000 ALTER TABLE `system_parameters` DISABLE KEYS */;
INSERT INTO `system_parameters` VALUES (1,'system','update','count','0'),(2,'system','update','retry','1658306126'),(3,'cms','theme','active','\"kptheme\"');
/*!40000 ALTER TABLE `system_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_plugin_history`
--

DROP TABLE IF EXISTS `system_plugin_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_plugin_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_plugin_history_code_index` (`code`),
  KEY `system_plugin_history_type_index` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_plugin_history`
--

LOCK TABLES `system_plugin_history` WRITE;
/*!40000 ALTER TABLE `system_plugin_history` DISABLE KEYS */;
INSERT INTO `system_plugin_history` VALUES (1,'Winter.Demo','comment','1.0.1','First version of Demo','2022-07-19 05:35:06'),(2,'Winter.Blog','script','1.0.1','v1.0.1/create_posts_table.php','2022-07-19 05:42:02'),(3,'Winter.Blog','script','1.0.1','v1.0.1/create_categories_table.php','2022-07-19 05:42:02'),(4,'Winter.Blog','script','1.0.1','v1.0.1/seed_all_tables.php','2022-07-19 05:42:02'),(5,'Winter.Blog','comment','1.0.1','Initialize plugin.','2022-07-19 05:42:02'),(6,'Winter.Blog','comment','1.0.2','Added the processed HTML content column to the posts table.','2022-07-19 05:42:02'),(7,'Winter.Blog','comment','1.0.3','Category component has been merged with Posts component.','2022-07-19 05:42:02'),(8,'Winter.Blog','comment','1.0.4','Improvements to the Posts list management UI.','2022-07-19 05:42:02'),(9,'Winter.Blog','comment','1.0.5','Removes the Author column from blog post list.','2022-07-19 05:42:02'),(10,'Winter.Blog','comment','1.0.6','Featured images now appear in the Post component.','2022-07-19 05:42:02'),(11,'Winter.Blog','comment','1.0.7','Added support for the Static Pages menus.','2022-07-19 05:42:02'),(12,'Winter.Blog','comment','1.0.8','Added total posts to category list.','2022-07-19 05:42:02'),(13,'Winter.Blog','comment','1.0.9','Added support for the Sitemap plugin.','2022-07-19 05:42:02'),(14,'Winter.Blog','comment','1.0.10','Added permission to prevent users from seeing posts they did not create.','2022-07-19 05:42:02'),(15,'Winter.Blog','comment','1.0.11','Deprecate \"idParam\" component property in favour of \"slug\" property.','2022-07-19 05:42:02'),(16,'Winter.Blog','comment','1.0.12','Fixes issue where images cannot be uploaded caused by latest Markdown library.','2022-07-19 05:42:02'),(17,'Winter.Blog','comment','1.0.13','Fixes problem with providing pages to Sitemap and Pages plugins.','2022-07-19 05:42:02'),(18,'Winter.Blog','comment','1.0.14','Add support for CSRF protection feature added to core.','2022-07-19 05:42:02'),(19,'Winter.Blog','comment','1.1.0','Replaced the Post editor with the new core Markdown editor.','2022-07-19 05:42:02'),(20,'Winter.Blog','comment','1.1.1','Posts can now be imported and exported.','2022-07-19 05:42:02'),(21,'Winter.Blog','comment','1.1.2','Posts are no longer visible if the published date has not passed.','2022-07-19 05:42:02'),(22,'Winter.Blog','comment','1.1.3','Added a New Post shortcut button to the blog menu.','2022-07-19 05:42:02'),(23,'Winter.Blog','script','1.2.0','v1.2.0/categories_add_nested_fields.php','2022-07-19 05:42:02'),(24,'Winter.Blog','comment','1.2.0','Categories now support nesting.','2022-07-19 05:42:02'),(25,'Winter.Blog','comment','1.2.1','Post slugs now must be unique.','2022-07-19 05:42:02'),(26,'Winter.Blog','comment','1.2.2','Fixes issue on new installs.','2022-07-19 05:42:02'),(27,'Winter.Blog','comment','1.2.3','Minor user interface update.','2022-07-19 05:42:02'),(28,'Winter.Blog','script','1.2.4','v1.2.4/update_timestamp_nullable.php','2022-07-19 05:42:02'),(29,'Winter.Blog','comment','1.2.4','Database maintenance. Updated all timestamp columns to be nullable.','2022-07-19 05:42:02'),(30,'Winter.Blog','comment','1.2.5','Added translation support for blog posts.','2022-07-19 05:42:02'),(31,'Winter.Blog','comment','1.2.6','The published field can now supply a time with the date.','2022-07-19 05:42:02'),(32,'Winter.Blog','comment','1.2.7','Introduced a new RSS feed component.','2022-07-19 05:42:02'),(33,'Winter.Blog','comment','1.2.8','Fixes issue with translated `content_html` attribute on blog posts.','2022-07-19 05:42:02'),(34,'Winter.Blog','comment','1.2.9','Added translation support for blog categories.','2022-07-19 05:42:02'),(35,'Winter.Blog','comment','1.2.10','Added translation support for post slugs.','2022-07-19 05:42:03'),(36,'Winter.Blog','comment','1.2.11','Fixes bug where excerpt is not translated.','2022-07-19 05:42:03'),(37,'Winter.Blog','comment','1.2.12','Description field added to category form.','2022-07-19 05:42:03'),(38,'Winter.Blog','comment','1.2.13','Improved support for Static Pages menus, added a blog post and all blog posts.','2022-07-19 05:42:03'),(39,'Winter.Blog','comment','1.2.14','Added post exception property to the post list component, useful for showing related posts.','2022-07-19 05:42:03'),(40,'Winter.Blog','comment','1.2.15','Back-end navigation sort order updated.','2022-07-19 05:42:03'),(41,'Winter.Blog','comment','1.2.16','Added `nextPost` and `previousPost` to the blog post component.','2022-07-19 05:42:03'),(42,'Winter.Blog','comment','1.2.17','Improved the next and previous logic to sort by the published date.','2022-07-19 05:42:03'),(43,'Winter.Blog','comment','1.2.18','Minor change to internals.','2022-07-19 05:42:03'),(44,'Winter.Blog','comment','1.2.19','Improved support for Build 420+','2022-07-19 05:42:03'),(45,'Winter.Blog','script','1.3.0','v1.3.0/posts_add_metadata.php','2022-07-19 05:42:03'),(46,'Winter.Blog','comment','1.3.0','Added metadata column for plugins to store data in','2022-07-19 05:42:03'),(47,'Winter.Blog','comment','1.3.1','Fixed metadata column not being jsonable','2022-07-19 05:42:03'),(48,'Winter.Blog','comment','1.3.2','Allow custom slug name for components, add 404 handling for missing blog posts, allow exporting of blog images.','2022-07-19 05:42:03'),(49,'Winter.Blog','comment','1.3.3','Fixed \'excluded categories\' filter from being run when value is empty.','2022-07-19 05:42:03'),(50,'Winter.Blog','comment','1.3.4','Allow post author to be specified. Improved translations.','2022-07-19 05:42:03'),(51,'Winter.Blog','comment','1.3.5','Fixed missing user info from breaking initial seeder in migrations. Fixed a PostgreSQL issue with blog exports.','2022-07-19 05:42:03'),(52,'Winter.Blog','comment','1.3.6','Improved French translations.','2022-07-19 05:42:03'),(53,'Winter.Blog','comment','1.4.0','Stability improvements. Rollback custom slug names for components','2022-07-19 05:42:03'),(54,'Winter.Blog','comment','1.4.1','Fixes potential security issue with unsafe Markdown. Allow blog bylines to be translated.','2022-07-19 05:42:03'),(55,'Winter.Blog','comment','1.4.2','Fix 404 redirects for missing blog posts. Assign current category to the listed posts when using the Posts component on a page with the category parameter available.','2022-07-19 05:42:03'),(56,'Winter.Blog','comment','1.4.3','Fixes incompatibility with locale switching when plugin is used in conjunction with the Translate plugin. Fixes undefined category error.','2022-07-19 05:42:03'),(57,'Winter.Blog','comment','1.4.4','Rollback translated bylines, please move or override the default component markup instead.','2022-07-19 05:42:03'),(58,'Winter.Blog','comment','1.5.0','Implement support for October CMS v2.0','2022-07-19 05:42:03'),(59,'Winter.Blog','script','2.0.0','v2.0.0/rename_tables.php','2022-07-19 05:42:03'),(60,'Winter.Blog','comment','2.0.0','Rebrand to Winter.Blog','2022-07-19 05:42:03'),(61,'Winter.Builder','comment','1.0.1','Initialize plugin.','2022-07-19 05:42:27'),(62,'Winter.Builder','comment','1.0.2','Fixes the problem with selecting a plugin. Minor localization corrections. Configuration files in the list and form behaviors are now autocomplete.','2022-07-19 05:42:27'),(63,'Winter.Builder','comment','1.0.3','Improved handling of the enum data type.','2022-07-19 05:42:27'),(64,'Winter.Builder','comment','1.0.4','Added user permissions to work with the Builder.','2022-07-19 05:42:27'),(65,'Winter.Builder','comment','1.0.5','Fixed permissions registration.','2022-07-19 05:42:27'),(66,'Winter.Builder','comment','1.0.6','Fixed front-end record ordering in the Record List component.','2022-07-19 05:42:27'),(67,'Winter.Builder','comment','1.0.7','Builder settings are now protected with user permissions. The database table column list is scrollable now. Minor code cleanup.','2022-07-19 05:42:27'),(68,'Winter.Builder','comment','1.0.8','Added the Reorder Controller behavior.','2022-07-19 05:42:27'),(69,'Winter.Builder','comment','1.0.9','Minor API and UI updates.','2022-07-19 05:42:27'),(70,'Winter.Builder','comment','1.0.10','Minor styling update.','2022-07-19 05:42:27'),(71,'Winter.Builder','comment','1.0.11','Fixed a bug where clicking placeholder in a repeater would open Inspector. Fixed a problem with saving forms with repeaters in tabs. Minor style fix.','2022-07-19 05:42:27'),(72,'Winter.Builder','comment','1.0.12','Added support for the Trigger property to the Media Finder widget configuration. Names of form fields and list columns definition files can now contain underscores.','2022-07-19 05:42:27'),(73,'Winter.Builder','comment','1.0.13','Minor styling fix on the database editor.','2022-07-19 05:42:27'),(74,'Winter.Builder','comment','1.0.14','Added support for published_at timestamp field','2022-07-19 05:42:27'),(75,'Winter.Builder','comment','1.0.15','Fixed a bug where saving a localization string in Inspector could cause a JavaScript error. Added support for Timestamps and Soft Deleting for new models.','2022-07-19 05:42:27'),(76,'Winter.Builder','comment','1.0.16','Fixed a bug when saving a form with the Repeater widget in a tab could create invalid fields in the form\'s outside area. Added a check that prevents creating localization strings inside other existing strings.','2022-07-19 05:42:27'),(77,'Winter.Builder','comment','1.0.17','Added support Trigger attribute support for RecordFinder and Repeater form widgets.','2022-07-19 05:42:27'),(78,'Winter.Builder','comment','1.0.18','Fixes a bug where \'::class\' notations in a model class definition could prevent the model from appearing in the Builder model list. Added emptyOption property support to the dropdown form control.','2022-07-19 05:42:27'),(79,'Winter.Builder','comment','1.0.19','Added a feature allowing to add all database columns to a list definition. Added max length validation for database table and column names.','2022-07-19 05:42:27'),(80,'Winter.Builder','comment','1.0.20','Fixes a bug where form the builder could trigger the \"current.hasAttribute is not a function\" error.','2022-07-19 05:42:27'),(81,'Winter.Builder','comment','1.0.21','Back-end navigation sort order updated.','2022-07-19 05:42:27'),(82,'Winter.Builder','comment','1.0.22','Added scopeValue property to the RecordList component.','2022-07-19 05:42:27'),(83,'Winter.Builder','comment','1.0.23','Added support for balloon-selector field type, added Brazilian Portuguese translation, fixed some bugs','2022-07-19 05:42:27'),(84,'Winter.Builder','comment','1.0.24','Added support for tag list field type, added read only toggle for fields. Prevent plugins from using reserved PHP keywords for class names and namespaces','2022-07-19 05:42:27'),(85,'Winter.Builder','comment','1.0.25','Allow editing of migration code in the \"Migration\" popup when saving changes in the database editor.','2022-07-19 05:42:27'),(86,'Winter.Builder','comment','1.0.26','Allow special default values for columns and added new \"Add ID column\" button to database editor.','2022-07-19 05:42:27'),(87,'Winter.Builder','comment','1.0.27','Added ability to use \'scope\' in a form relation field, added ability to change the sort order of versions and added additional properties for repeater widget in form builder. Added Polish translation.','2022-07-19 05:42:27'),(88,'Winter.Builder','script','2.0.0','v2.0.0/convert_data.php','2022-07-19 05:42:27'),(89,'Winter.Builder','comment','2.0.0','Rebrand to Winter.Builder','2022-07-19 05:42:27'),(90,'Winter.Builder','comment','2.0.0','Fixes namespace parsing on php >= 8.0','2022-07-19 05:42:27'),(91,'Winter.Pages','comment','1.0.1','Implemented the static pages management and the Static Page component.','2022-07-19 05:42:44'),(92,'Winter.Pages','comment','1.0.2','Fixed the page preview URL.','2022-07-19 05:42:44'),(93,'Winter.Pages','comment','1.0.3','Implemented menus.','2022-07-19 05:42:44'),(94,'Winter.Pages','comment','1.0.4','Implemented the content block management and placeholder support.','2022-07-19 05:42:44'),(95,'Winter.Pages','comment','1.0.5','Added support for the Sitemap plugin.','2022-07-19 05:42:44'),(96,'Winter.Pages','comment','1.0.6','Minor updates to the internal API.','2022-07-19 05:42:44'),(97,'Winter.Pages','comment','1.0.7','Added the Snippets feature.','2022-07-19 05:42:44'),(98,'Winter.Pages','comment','1.0.8','Minor improvements to the code.','2022-07-19 05:42:44'),(99,'Winter.Pages','comment','1.0.9','Fixes issue where Snippet tab is missing from the Partials form.','2022-07-19 05:42:44'),(100,'Winter.Pages','comment','1.0.10','Add translations for various locales.','2022-07-19 05:42:44'),(101,'Winter.Pages','comment','1.0.11','Fixes issue where placeholders tabs were missing from Page form.','2022-07-19 05:42:44'),(102,'Winter.Pages','comment','1.0.12','Implement Media Manager support.','2022-07-19 05:42:44'),(103,'Winter.Pages','script','1.1.0','v1.1.0/snippets_rename_viewbag_properties.php','2022-07-19 05:42:44'),(104,'Winter.Pages','comment','1.1.0','Adds meta title and description to pages. Adds |staticPage filter.','2022-07-19 05:42:44'),(105,'Winter.Pages','comment','1.1.1','Add support for Syntax Fields.','2022-07-19 05:42:44'),(106,'Winter.Pages','comment','1.1.2','Static Breadcrumbs component now respects the hide from navigation setting.','2022-07-19 05:42:44'),(107,'Winter.Pages','comment','1.1.3','Minor back-end styling fix.','2022-07-19 05:42:44'),(108,'Winter.Pages','comment','1.1.4','Minor fix to the StaticPage component API.','2022-07-19 05:42:44'),(109,'Winter.Pages','comment','1.1.5','Fixes bug when using syntax fields.','2022-07-19 05:42:44'),(110,'Winter.Pages','comment','1.1.6','Minor styling fix to the back-end UI.','2022-07-19 05:42:44'),(111,'Winter.Pages','comment','1.1.7','Improved menu item form to include CSS class, open in a new window and hidden flag.','2022-07-19 05:42:44'),(112,'Winter.Pages','comment','1.1.8','Improved the output of snippet partials when saved.','2022-07-19 05:42:44'),(113,'Winter.Pages','comment','1.1.9','Minor update to snippet inspector internal API.','2022-07-19 05:42:44'),(114,'Winter.Pages','comment','1.1.10','Fixes a bug where selecting a layout causes permanent unsaved changes.','2022-07-19 05:42:44'),(115,'Winter.Pages','comment','1.1.11','Add support for repeater syntax field.','2022-07-19 05:42:44'),(116,'Winter.Pages','comment','1.2.0','Added support for translations, UI updates.','2022-07-19 05:42:44'),(117,'Winter.Pages','comment','1.2.1','Use nice titles when listing the content files.','2022-07-19 05:42:44'),(118,'Winter.Pages','comment','1.2.2','Minor styling update.','2022-07-19 05:42:44'),(119,'Winter.Pages','comment','1.2.3','Snippets can now be moved by dragging them.','2022-07-19 05:42:44'),(120,'Winter.Pages','comment','1.2.4','Fixes a bug where the cursor is misplaced when editing text files.','2022-07-19 05:42:44'),(121,'Winter.Pages','comment','1.2.5','Fixes a bug where the parent page is lost upon changing a page layout.','2022-07-19 05:42:45'),(122,'Winter.Pages','comment','1.2.6','Shared view variables are now passed to static pages.','2022-07-19 05:42:45'),(123,'Winter.Pages','comment','1.2.7','Fixes issue with duplicating properties when adding multiple snippets on the same page.','2022-07-19 05:42:45'),(124,'Winter.Pages','comment','1.2.8','Fixes a bug where creating a content block without extension doesn\'t save the contents to file.','2022-07-19 05:42:45'),(125,'Winter.Pages','comment','1.2.9','Add conditional support for translating page URLs.','2022-07-19 05:42:45'),(126,'Winter.Pages','comment','1.2.10','Streamline generation of URLs to use the new Cms::url helper.','2022-07-19 05:42:45'),(127,'Winter.Pages','comment','1.2.11','Implements repeater usage with translate plugin.','2022-07-19 05:42:45'),(128,'Winter.Pages','comment','1.2.12','Fixes minor issue when using snippets and switching the application locale.','2022-07-19 05:42:45'),(129,'Winter.Pages','comment','1.2.13','Fixes bug when AJAX is used on a page that does not yet exist.','2022-07-19 05:42:45'),(130,'Winter.Pages','comment','1.2.14','Add theme logging support for changes made to menus.','2022-07-19 05:42:45'),(131,'Winter.Pages','comment','1.2.15','Back-end navigation sort order updated.','2022-07-19 05:42:45'),(132,'Winter.Pages','comment','1.2.16','Fixes a bug when saving a template that has been modified outside of the CMS (mtime mismatch).','2022-07-19 05:42:45'),(133,'Winter.Pages','comment','1.2.17','Changes locations of custom fields to secondary tabs instead of the primary Settings area. New menu search ability on adding menu items','2022-07-19 05:42:45'),(134,'Winter.Pages','comment','1.2.18','Fixes cache-invalidation issues when Winter.Translate is not installed. Added Greek & Simplified Chinese translations. Removed deprecated calls. Allowed saving HTML in snippet properties. Added support for the MediaFinder in menu items.','2022-07-19 05:42:45'),(135,'Winter.Pages','comment','1.2.19','Catch exception with corrupted menu file.','2022-07-19 05:42:45'),(136,'Winter.Pages','comment','1.2.20','StaticMenu component now exposes menuName property; added pages.menu.referencesGenerated event.','2022-07-19 05:42:45'),(137,'Winter.Pages','comment','1.2.21','Fixes a bug where last Static Menu item cannot be deleted. Improved Persian, Slovak and Turkish translations.','2022-07-19 05:42:45'),(138,'Winter.Pages','comment','1.3.0','Added support for using Database-driven Themes when enabled in the CMS configuration.','2022-07-19 05:42:45'),(139,'Winter.Pages','comment','1.3.1','Added ChildPages Component, prevent hidden pages from being returned via menu item resolver.','2022-07-19 05:42:45'),(140,'Winter.Pages','comment','1.3.2','Fixes error when creating a subpage whose parent has no layout set.','2022-07-19 05:42:45'),(141,'Winter.Pages','comment','1.3.3','Improves user experience for users with only partial access through permissions','2022-07-19 05:42:45'),(142,'Winter.Pages','comment','1.3.4','Fix error where large menus were being truncated due to the PHP \"max_input_vars\" configuration value. Improved Slovenian translation.','2022-07-19 05:42:45'),(143,'Winter.Pages','comment','1.3.5','Minor fix to bust the browser cache for JS assets. Prevent duplicate property fields in snippet inspector.','2022-07-19 05:42:45'),(144,'Winter.Pages','comment','1.3.6','ChildPages component now displays localized page titles from Translate plugin.','2022-07-19 05:42:45'),(145,'Winter.Pages','comment','1.3.7','Improved page loading performance, added MenuPicker formwidget, added pages.snippets.listSnippets','2022-07-19 05:42:45'),(146,'Winter.Pages','comment','1.4.0','Fixes bug when adding menu items in October CMS v2.0.','2022-07-19 05:42:45'),(147,'Winter.Pages','comment','1.4.1','Fixes support for configuration values.','2022-07-19 05:42:45'),(148,'Winter.Pages','comment','1.4.3','Fixes page deletion in newer platform builds.','2022-07-19 05:42:45'),(149,'Winter.Pages','comment','2.0.0','Rebrand to Winter.Pages','2022-07-19 05:42:45');
/*!40000 ALTER TABLE `system_plugin_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_plugin_versions`
--

DROP TABLE IF EXISTS `system_plugin_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_plugin_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_frozen` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `system_plugin_versions_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_plugin_versions`
--

LOCK TABLES `system_plugin_versions` WRITE;
/*!40000 ALTER TABLE `system_plugin_versions` DISABLE KEYS */;
INSERT INTO `system_plugin_versions` VALUES (1,'Winter.Demo','1.0.1','2022-07-19 05:35:06',0,0),(2,'Winter.Blog','2.0.0','2022-07-19 05:42:03',0,0),(3,'Winter.Builder','2.0.0','2022-07-19 05:42:27',0,0),(4,'Winter.Pages','2.0.0','2022-07-19 05:42:45',0,0);
/*!40000 ALTER TABLE `system_plugin_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_request_logs`
--

DROP TABLE IF EXISTS `system_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_request_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_request_logs`
--

LOCK TABLES `system_request_logs` WRITE;
/*!40000 ALTER TABLE `system_request_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_request_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_revisions`
--

DROP TABLE IF EXISTS `system_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_revisions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cast` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`),
  KEY `system_revisions_user_id_index` (`user_id`),
  KEY `system_revisions_field_index` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_revisions`
--

LOCK TABLES `system_revisions` WRITE;
/*!40000 ALTER TABLE `system_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_settings_item_index` (`item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `winter_blog_categories`
--

DROP TABLE IF EXISTS `winter_blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `winter_blog_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `nest_left` int(11) DEFAULT NULL,
  `nest_right` int(11) DEFAULT NULL,
  `nest_depth` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rainlab_blog_categories_slug_index` (`slug`),
  KEY `rainlab_blog_categories_parent_id_index` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `winter_blog_categories`
--

LOCK TABLES `winter_blog_categories` WRITE;
/*!40000 ALTER TABLE `winter_blog_categories` DISABLE KEYS */;
INSERT INTO `winter_blog_categories` VALUES (1,'Uncategorized','uncategorized',NULL,NULL,NULL,1,2,0,'2022-07-19 05:42:02','2022-07-19 05:42:02'),(2,'Новини','news',NULL,'',NULL,3,4,0,'2022-07-19 07:55:50','2022-07-19 07:55:50');
/*!40000 ALTER TABLE `winter_blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `winter_blog_posts`
--

DROP TABLE IF EXISTS `winter_blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `winter_blog_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `metadata` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rainlab_blog_posts_user_id_index` (`user_id`),
  KEY `rainlab_blog_posts_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `winter_blog_posts`
--

LOCK TABLES `winter_blog_posts` WRITE;
/*!40000 ALTER TABLE `winter_blog_posts` DISABLE KEYS */;
INSERT INTO `winter_blog_posts` VALUES (1,1,'First blog post','first-blog-post','The first ever blog post is here. It might be a good idea to update this post with some more relevant content.','This is your first ever **blog post**! It might be a good idea to update this post with some more relevant content.\n\nYou can edit this content by selecting **Blog** from the administration back-end menu.\n\n*Enjoy the good times!*','<p>This is your first ever <strong>blog post</strong>! It might be a good idea to update this post with some more relevant content.</p>\n<p>You can edit this content by selecting <strong>Blog</strong> from the administration back-end menu.</p>\n<p><em>Enjoy the good times!</em></p>','2022-07-19 05:42:02',1,'2022-07-19 05:42:02','2022-07-19 05:42:02',NULL),(2,1,'Триває ремонт колектора від Новосвятошинської КНС','trivaye-remont-kolektora-vid-novosvyatoshinskoyi-kns','Ми продовжуємо забезпечувати стабільне водовідведення міста: щодня ремонтуємо каналізаційні трубопроводи та колектори, де виникають аварійні ситуації.','Ми продовжуємо забезпечувати стабільне водовідведення міста: щодня ремонтуємо каналізаційні трубопроводи та колектори, де виникають аварійні ситуації.\r\n\r\nТривають роботи з ремонту чавунного напірного колектора №3 діаметром 1000 мм  від каналізаційної насосної станції  \"Новосвятошинська\" по вул. Козелецькій. Наразі фахівцями встановлено фігурну накладну муфту, після чого буде здійснюватись нагнітання міжтрубного простору цементно-піщаним розчином, випробування та зворотня засипка.\r\n\r\nЦі роботи дозволять запустити дублюючий напірний колектор від  Новосвятошинської каналізаційної насосної станції,  що  підвищить надійність системи водовідведення Святошинського району в цілому. Крім того, колектор також приймає  стоки деяких прилеглих міст.\r\n\r\nМи завжди на варті стабільного водопостачання та водовідведення міста. Працюємо для вас з Україною в серці!','<p>Ми продовжуємо забезпечувати стабільне водовідведення міста: щодня ремонтуємо каналізаційні трубопроводи та колектори, де виникають аварійні ситуації.</p>\n<p>Тривають роботи з ремонту чавунного напірного колектора №3 діаметром 1000 мм  від каналізаційної насосної станції  &quot;Новосвятошинська&quot; по вул. Козелецькій. Наразі фахівцями встановлено фігурну накладну муфту, після чого буде здійснюватись нагнітання міжтрубного простору цементно-піщаним розчином, випробування та зворотня засипка.</p>\n<p>Ці роботи дозволять запустити дублюючий напірний колектор від  Новосвятошинської каналізаційної насосної станції,  що  підвищить надійність системи водовідведення Святошинського району в цілому. Крім того, колектор також приймає  стоки деяких прилеглих міст.</p>\n<p>Ми завжди на варті стабільного водопостачання та водовідведення міста. Працюємо для вас з Україною в серці!</p>','2022-07-18 18:00:00',1,'2022-07-19 07:55:26','2022-07-19 07:55:26',NULL),(3,1,'fghkghk','fghkghk','','Имя	Тел.	\r\nРЕС	Терминал-сервис	0675000443	\r\nКазна	ВАНЯ (Казначейство)	0661333227	\r\nКомунхоз	Женя - SoftProekt	0675698515	\r\nРЕС	Петрусенко Тетяна Валеріївна	0669392955	66-08\r\nРЕС	Ломовська Любов Леонидовна		66-00\r\nРЕС	Логін Света		66-07\r\nРЕС	Шевцова Любов Микол.		66-20\r\nРЕС	Цюняк Максим Я.		66-06\r\nРЕС	Ганін Вася		66-23\r\nРЕС	Мамай Віктор Петрович		66-11\r\nРЕС	Диспетчер	5-36-10	\r\nРЕС	Калабайда Дима		66-05\r\nРЕС	Добровиличковка РЕС програмист Коля		65-04\r\nРЕС	Александровка РЕС програмист Пасечник Коля	0976504890	\r\nКОЕ	Дмитренко Андрій Володимирович (Директор IT)	0672397199	\r\nКОЕ	Олейник Юрій Анатолійович (СІТ  - начальник)		14-27\r\nКОЕ	Білоткач Юра (Програмист Интернет)	0501368686	11-16\r\nКОЕ	Раца Микола  Іванович (Електромеханік)		11-36\r\nКОЕ	Патернак Дмитрий Александрович	0671901201	11-19\r\nКОЕ	Панасюк Андрій Михайлович (PrevInvoice)	0500417847	11-55\r\nКОЕ	Мошуренко Андрій (Abon)		14-28\r\nКОЕ	Раца Олег (Укрзалізниця)	0633046975	16-01(133)\r\nКОЕ	Кануннікова Марина Миколаївна (SAP R3)		16-01\r\nКОЕ	Кузьменко Наталя Володимирівна (SAP R3)		14-19\r\nКОЕ	Полікута Лариса Миколаївна		11-21\r\nКОЕ	Муцінов Сергей Анатолійович (CorpAb)		12-48\r\nКОЕ	Хотеев Андрій Григорович (Діловод)		15-33\r\nКОЕ	Кочубей Анатолій Васильович (Почта)	0671901205	11-22\r\nКОЕ	Кочубей Анатолій Васильович (Почта)	0993239837	\r\nКОЕ	Білоткач Олександр Сергійович (Адміністратор білінгових систем)	(067)190-12-75	11-25\r\n\r\n![](/storage/app/media/%D0%A2%D0%B5%D0%BB%D0%B5%D1%84%D0%BE%D0%BD%D1%8B.xlsx)','<p>Имя Тел.<br />\nРЕС Терминал-сервис 0675000443<br />\nКазна   ВАНЯ (Казначейство) 0661333227<br />\nКомунхоз    Женя - SoftProekt   0675698515<br />\nРЕС Петрусенко Тетяна Валеріївна    0669392955  66-08\nРЕС Ломовська Любов Леонидовна      66-00\nРЕС Логін Света     66-07\nРЕС Шевцова Любов Микол.        66-20\nРЕС Цюняк Максим Я.     66-06\nРЕС Ганін Вася      66-23\nРЕС Мамай Віктор Петрович       66-11\nРЕС Диспетчер   5-36-10\nРЕС Калабайда Дима      66-05\nРЕС Добровиличковка РЕС програмист Коля     65-04\nРЕС Александровка РЕС програмист Пасечник Коля  0976504890<br />\nКОЕ Дмитренко Андрій Володимирович (Директор IT)    0672397199<br />\nКОЕ Олейник Юрій Анатолійович (СІТ  - начальник)        14-27\nКОЕ Білоткач Юра (Програмист Интернет)  0501368686  11-16\nКОЕ Раца Микола  Іванович (Електромеханік)      11-36\nКОЕ Патернак Дмитрий Александрович  0671901201  11-19\nКОЕ Панасюк Андрій Михайлович (PrevInvoice) 0500417847  11-55\nКОЕ Мошуренко Андрій (Abon)     14-28\nКОЕ Раца Олег (Укрзалізниця)    0633046975  16-01(133)\nКОЕ Кануннікова Марина Миколаївна (SAP R3)      16-01\nКОЕ Кузьменко Наталя Володимирівна (SAP R3)     14-19\nКОЕ Полікута Лариса Миколаївна      11-21\nКОЕ Муцінов Сергей Анатолійович (CorpAb)        12-48\nКОЕ Хотеев Андрій Григорович (Діловод)      15-33\nКОЕ Кочубей Анатолій Васильович (Почта) 0671901205  11-22\nКОЕ Кочубей Анатолій Васильович (Почта) 0993239837<br />\nКОЕ Білоткач Олександр Сергійович (Адміністратор білінгових систем) (067)190-12-75  11-25</p>\n<p><img src=\"/storage/app/media/%D0%A2%D0%B5%D0%BB%D0%B5%D1%84%D0%BE%D0%BD%D1%8B.xlsx\" alt=\"\" /></p>','2022-07-18 18:00:00',1,'2022-07-19 11:14:02','2022-07-19 11:14:30',NULL);
/*!40000 ALTER TABLE `winter_blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `winter_blog_posts_categories`
--

DROP TABLE IF EXISTS `winter_blog_posts_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `winter_blog_posts_categories` (
  `post_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`post_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `winter_blog_posts_categories`
--

LOCK TABLES `winter_blog_posts_categories` WRITE;
/*!40000 ALTER TABLE `winter_blog_posts_categories` DISABLE KEYS */;
INSERT INTO `winter_blog_posts_categories` VALUES (2,2),(3,2);
/*!40000 ALTER TABLE `winter_blog_posts_categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-22 18:07:57
